import type { ExchangeCode } from './common.types';

export interface ScreenerFieldOption { value: string; label: string; }
export interface ScreenerFieldDef {
  group: 'instrument' | 'sma' | 'pivot' | 'candle' | 'signal';
  key: string;
  label: string;
  operators: string[];
  valueType: 'single' | 'list' | 'range' | 'relative';
  options?: ScreenerFieldOption[];
}
export interface ScreenerFilterMetadataDto {
  exchangeCode: string;
  timeframes: string[];
  fields: ScreenerFieldDef[];
}

export type ScreenerValue =
  | { kind: 'single'; value: string | number | boolean | null }
  | { kind: 'list'; values: Array<string | number | boolean> }
  | { kind: 'range'; min?: number | string | null; max?: number | string | null }
  | { kind: 'relative'; unit: 'atr' | 'percent' | 'bars'; value: number };

export interface ScreenerConditionNodeDto {
  type: 'condition';
  id: string;
  enabled: boolean;
  fieldGroup: 'instrument' | 'sma' | 'pivot' | 'candle' | 'signal';
  field: string;
  timeframe: 'current' | 'hour' | 'day' | 'week';
  operator: string;
  value: ScreenerValue;
}

export interface ScreenerFilterGroupDto {
  type: 'group';
  id: string;
  operator: 'AND' | 'OR';
  enabled: boolean;
  children: Array<ScreenerFilterNodeDto>;
}

export type ScreenerFilterNodeDto = ScreenerConditionNodeDto | ScreenerFilterGroupDto;

export interface ScreenerRunRequestDto {
  exchangeCode: ExchangeCode;
  tradeDate: string;
  defaultTimeframe: 'hour' | 'day' | 'week';
  filterTree: ScreenerFilterGroupDto;
  pagination: { pageIndex: number; pageSize: number };
  sort: Array<{ field: string; direction: 'asc' | 'desc' }>;
}
export interface ScreenerResultRowDto {
  instrumentId: number;
  symbol: string;
  sector?: string | null;
  timeframe: string;
  latestClose?: number | null;
  currentCandleType?: string | null;
  latestPivotType?: string | null;
  previousPivotType?: string | null;
  smaAlignmentSummary?: string | null;
  signalSummary?: string | null;
  updatedAt?: string | null;
}
export interface ScreenerRunResponseDto {
  rows: ScreenerResultRowDto[];
  totalRows: number;
  pageIndex: number;
  pageSize: number;
}
export interface ScreenerCountResponseDto { count: number; }
