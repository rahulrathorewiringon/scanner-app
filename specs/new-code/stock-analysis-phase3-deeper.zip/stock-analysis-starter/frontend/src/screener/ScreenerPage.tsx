import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { useWorkspaceStore } from '../stores/workspace.store';
import { useScreenerFilterMetadataQuery } from '../hooks/api/useScreenerFilterMetadataQuery';
import { useScreenerCountMutation } from '../hooks/api/useScreenerCountMutation';
import { useScreenerRunMutation } from '../hooks/api/useScreenerRunMutation';
import type { ScreenerConditionNodeDto, ScreenerFieldDef, ScreenerFilterGroupDto, ScreenerFilterNodeDto, ScreenerRunRequestDto } from '../types/screener.types';

function id() {
  return Math.random().toString(36).slice(2, 10);
}

function createCondition(field?: ScreenerFieldDef): ScreenerConditionNodeDto {
  return {
    type: 'condition',
    id: id(),
    enabled: true,
    fieldGroup: field?.group ?? 'instrument',
    field: field?.key ?? 'symbol',
    timeframe: 'day',
    operator: field?.operators?.[0] ?? 'eq',
    value: field?.options?.length ? { kind: 'single', value: field.options[0].value } : { kind: 'single', value: '' },
  };
}

function createGroup(): ScreenerFilterGroupDto {
  return { type: 'group', id: id(), operator: 'AND', enabled: true, children: [] };
}

function updateNode(group: ScreenerFilterGroupDto, targetId: string, updater: (node: ScreenerFilterNodeDto) => ScreenerFilterNodeDto): ScreenerFilterGroupDto {
  return {
    ...group,
    children: group.children.map((child) => {
      if (child.id === targetId) return updater(child);
      if (child.type === 'group') return updateNode(child, targetId, updater);
      return child;
    }),
  };
}

function addChild(group: ScreenerFilterGroupDto, groupId: string, child: ScreenerFilterNodeDto): ScreenerFilterGroupDto {
  if (group.id === groupId) return { ...group, children: [...group.children, child] };
  return { ...group, children: group.children.map((node) => node.type === 'group' ? addChild(node, groupId, child) : node) };
}

function removeNode(group: ScreenerFilterGroupDto, nodeId: string): ScreenerFilterGroupDto {
  return {
    ...group,
    children: group.children
      .filter((child) => child.id !== nodeId)
      .map((child) => child.type === 'group' ? removeNode(child, nodeId) : child),
  };
}

export default function ScreenerPage() {
  const exchangeCode = useWorkspaceStore((s) => s.exchangeCode);
  const tradeDate = useWorkspaceStore((s) => s.tradeDate);
  const setActiveInstrumentId = useWorkspaceStore((s) => s.setActiveInstrumentId);
  const [timeframe, setTimeframe] = useState<'hour'|'day'|'week'>('day');
  const metadata = useScreenerFilterMetadataQuery(exchangeCode);
  const countMutation = useScreenerCountMutation();
  const runMutation = useScreenerRunMutation();
  const [filterTree, setFilterTree] = useState<ScreenerFilterGroupDto>({
    type: 'group', id: 'root', operator: 'AND', enabled: true, children: []
  });

  const request = useMemo<ScreenerRunRequestDto>(() => ({
    exchangeCode,
    tradeDate,
    defaultTimeframe: timeframe,
    filterTree,
    pagination: { pageIndex: 0, pageSize: 50 },
    sort: [{ field: 'symbol', direction: 'asc' }],
  }), [exchangeCode, tradeDate, timeframe, filterTree]);

  const runCount = () => countMutation.mutate(request);
  const runScreener = () => runMutation.mutate(request);

  return (
    <div style={{ padding: 20, display: 'grid', gap: 16 }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <div>
          <h1 style={{ margin:0 }}>Screener</h1>
          <div style={{ opacity:0.75 }}>Metadata-driven filter groups, nested operators, SQL-backed count/run</div>
        </div>
        <div style={{ display:'flex', gap:10 }}>
          <button onClick={runCount} style={{ padding:'10px 14px', background:'#334155', borderRadius:8 }}>Count</button>
          <button onClick={runScreener} style={{ padding:'10px 14px', background:'#2563eb', borderRadius:8 }}>Run Screener</button>
        </div>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1.2fr 0.8fr', gap:16 }}>
        <div style={{ border:'1px solid #243043', borderRadius:8, background:'#111827', padding:16, display:'grid', gap:12 }}>
          <div style={{ display:'flex', gap:12, alignItems:'center' }}>
            <select value={timeframe} onChange={(e) => setTimeframe(e.target.value as any)} style={{ padding:8 }}>
              <option value='hour'>hour</option>
              <option value='day'>day</option>
              <option value='week'>week</option>
            </select>
            <button onClick={() => setFilterTree(addChild(filterTree, 'root', createCondition(metadata.data?.fields?.[0])))}>+ Condition</button>
            <button onClick={() => setFilterTree(addChild(filterTree, 'root', createGroup()))}>+ Group</button>
          </div>
          <FilterGroupEditor
            group={filterTree}
            metadata={metadata.data?.fields ?? []}
            onChange={setFilterTree}
            onAddCondition={(groupId) => setFilterTree((prev) => addChild(prev, groupId, createCondition(metadata.data?.fields?.[0])))}
            onAddGroup={(groupId) => setFilterTree((prev) => addChild(prev, groupId, createGroup()))}
            onRemoveNode={(nodeId) => setFilterTree((prev) => removeNode(prev, nodeId))}
          />
        </div>

        <div style={{ border:'1px solid #243043', borderRadius:8, background:'#111827', padding:16, display:'grid', gap:12 }}>
          <h3 style={{ marginTop:0 }}>Execution Summary</h3>
          <div>Count: {countMutation.data?.count ?? '—'}</div>
          <div>Rows: {runMutation.data?.totalRows ?? '—'}</div>
          <div>Exchange: {exchangeCode}</div>
          <div>Trade Date: {tradeDate}</div>
          <div>Metadata fields: {metadata.data?.fields?.length ?? 0}</div>
          <pre style={{ whiteSpace:'pre-wrap', background:'#0b1220', padding:12, borderRadius:8, overflow:'auto', fontSize:12 }}>
            {JSON.stringify(request, null, 2)}
          </pre>
        </div>
      </div>

      <div style={{ border:'1px solid #243043', borderRadius:8, background:'#111827', padding:16 }}>
        <h3 style={{ marginTop:0 }}>Results</h3>
        {runMutation.isPending ? <div>Running screener…</div> : runMutation.error ? <div>Failed to run screener.</div> : (
          <table style={{ width:'100%', borderCollapse:'collapse' }}>
            <thead>
              <tr>
                {['Symbol', 'Sector', 'TF', 'Close', 'Candle', 'Pivot', 'Prev Pivot', 'SMA', 'Signal', 'Actions'].map((h) => (
                  <th key={h} style={{ textAlign:'left', padding:'8px 6px', borderBottom:'1px solid #243043' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {runMutation.data?.rows?.map((row) => (
                <tr key={row.instrumentId}>
                  <td style={cell}>{row.symbol}</td>
                  <td style={cell}>{row.sector ?? '—'}</td>
                  <td style={cell}>{row.timeframe}</td>
                  <td style={cell}>{row.latestClose ?? '—'}</td>
                  <td style={cell}>{row.currentCandleType ?? '—'}</td>
                  <td style={cell}>{row.latestPivotType ?? '—'}</td>
                  <td style={cell}>{row.previousPivotType ?? '—'}</td>
                  <td style={cell}>{row.smaAlignmentSummary ?? '—'}</td>
                  <td style={cell}>{row.signalSummary ?? '—'}</td>
                  <td style={cell}>
                    <Link to="/workspace" onClick={() => setActiveInstrumentId(row.instrumentId)} style={{ color:'#60a5fa' }}>Open</Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

function FilterGroupEditor({
  group,
  metadata,
  onChange,
  onAddCondition,
  onAddGroup,
  onRemoveNode,
}: {
  group: ScreenerFilterGroupDto;
  metadata: ScreenerFieldDef[];
  onChange: (next: ScreenerFilterGroupDto) => void;
  onAddCondition: (groupId: string) => void;
  onAddGroup: (groupId: string) => void;
  onRemoveNode: (nodeId: string) => void;
}) {
  return (
    <div style={{ border:'1px solid #243043', borderRadius:8, padding:12, display:'grid', gap:10 }}>
      <div style={{ display:'flex', gap:8, alignItems:'center' }}>
        <strong>Group {group.id === 'root' ? '(root)' : ''}</strong>
        <select value={group.operator} onChange={(e) => onChange({ ...group, operator: e.target.value as 'AND' | 'OR' })}>
          <option value='AND'>AND</option>
          <option value='OR'>OR</option>
        </select>
        {group.id !== 'root' && <button onClick={() => onRemoveNode(group.id)}>Remove Group</button>}
        <button onClick={() => onAddCondition(group.id)}>+ Condition</button>
        <button onClick={() => onAddGroup(group.id)}>+ Group</button>
      </div>
      {group.children.length === 0 && <div style={{ opacity:0.65 }}>No conditions yet.</div>}
      {group.children.map((child) => child.type === 'group' ? (
        <FilterGroupEditor
          key={child.id}
          group={child}
          metadata={metadata}
          onChange={(next) => onChange(updateNode(group, next.id, () => next))}
          onAddCondition={onAddCondition}
          onAddGroup={onAddGroup}
          onRemoveNode={onRemoveNode}
        />
      ) : (
        <ConditionRow
          key={child.id}
          node={child}
          metadata={metadata}
          onChange={(next) => onChange(updateNode(group, next.id, () => next))}
          onRemove={() => onRemoveNode(child.id)}
        />
      ))}
    </div>
  );
}

function ConditionRow({ node, metadata, onChange, onRemove }: { node: ScreenerConditionNodeDto; metadata: ScreenerFieldDef[]; onChange: (next: ScreenerConditionNodeDto) => void; onRemove: () => void; }) {
  const fieldDef = metadata.find((f) => f.key === node.field) ?? metadata[0];
  const available = metadata.filter((f) => f.group === node.fieldGroup);
  const fieldsToShow = available.length ? available : metadata;
  return (
    <div style={{ display:'grid', gridTemplateColumns:'140px 180px 120px 120px 1fr auto', gap:8, alignItems:'center', border:'1px solid #1f2937', padding:8, borderRadius:8 }}>
      <select value={node.fieldGroup} onChange={(e) => {
        const nextField = metadata.find((f) => f.group === e.target.value) ?? metadata[0];
        onChange({ ...node, fieldGroup: e.target.value as any, field: nextField?.key ?? node.field, operator: nextField?.operators?.[0] ?? node.operator, value: nextField?.options?.length ? { kind:'single', value: nextField.options[0].value } : { kind:'single', value:'' } });
      }}>
        {['instrument','sma','pivot','candle','signal'].map((group) => <option key={group} value={group}>{group}</option>)}
      </select>
      <select value={node.field} onChange={(e) => {
        const nextField = metadata.find((f) => f.key === e.target.value) ?? fieldDef;
        onChange({ ...node, field: e.target.value, fieldGroup: nextField.group, operator: nextField.operators[0], value: nextField.options?.length ? { kind:'single', value: nextField.options[0].value } : { kind:'single', value:'' } });
      }}>
        {fieldsToShow.map((field) => <option key={field.key} value={field.key}>{field.label}</option>)}
      </select>
      <select value={node.timeframe} onChange={(e) => onChange({ ...node, timeframe: e.target.value as any })}>
        {['current','hour','day','week'].map((tf) => <option key={tf} value={tf}>{tf}</option>)}
      </select>
      <select value={node.operator} onChange={(e) => onChange({ ...node, operator: e.target.value })}>
        {(fieldDef?.operators ?? ['eq']).map((operator) => <option key={operator} value={operator}>{operator}</option>)}
      </select>
      {fieldDef?.options?.length ? (
        fieldDef.operators.includes('in') && node.operator === 'in' ? (
          <select multiple value={node.value.kind === 'list' ? node.value.values.map(String) : []} onChange={(e) => onChange({ ...node, value: { kind:'list', values: Array.from(e.target.selectedOptions).map((opt) => opt.value) } })} style={{ minHeight:64 }}>
            {fieldDef.options.map((opt) => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
          </select>
        ) : (
          <select value={node.value.kind === 'single' ? String(node.value.value ?? '') : ''} onChange={(e) => onChange({ ...node, value: { kind:'single', value: e.target.value } })}>
            {fieldDef.options.map((opt) => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
          </select>
        )
      ) : (
        <input value={node.value.kind === 'single' ? String(node.value.value ?? '') : ''} onChange={(e) => onChange({ ...node, value: { kind:'single', value: e.target.value } })} placeholder='Value' />
      )}
      <button onClick={onRemove}>Remove</button>
    </div>
  );
}

const cell: React.CSSProperties = { padding:'8px 6px', borderBottom:'1px solid #1f2937' };
