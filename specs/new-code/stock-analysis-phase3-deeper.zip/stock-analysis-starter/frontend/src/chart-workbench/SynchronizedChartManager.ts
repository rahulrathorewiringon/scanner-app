import type { IChartApi, LogicalRange, MouseEventParams } from 'lightweight-charts';
import type { CrosshairState } from '../stores/workspace.store';

type ChartKey = 'week' | 'day' | 'hour';
type CrosshairListener = (state: CrosshairState) => void;
type RangeListener = (range: LogicalRange) => void;

type RegisteredChart = {
  chart: IChartApi;
  getCrosshairState?: (param: MouseEventParams<any>) => CrosshairState | null;
};

export class SynchronizedChartManager {
  private charts = new Map<ChartKey, RegisteredChart>();
  private applying = false;
  private rangeListeners = new Set<RangeListener>();
  private crosshairListeners = new Set<CrosshairListener>();

  register(key: ChartKey, chart: IChartApi, getCrosshairState?: (param: MouseEventParams<any>) => CrosshairState | null) {
    this.charts.set(key, { chart, getCrosshairState });
    chart.timeScale().subscribeVisibleLogicalRangeChange((range) => {
      if (this.applying || !range) return;
      this.broadcastRange(key, range);
      this.rangeListeners.forEach((listener) => listener(range));
    });
    chart.subscribeCrosshairMove((param) => {
      const state = getCrosshairState?.(param);
      if (!state) return;
      this.crosshairListeners.forEach((listener) => listener({ source: key, ...state }));
    });
  }

  unregister(key: ChartKey) {
    this.charts.delete(key);
  }

  onVisibleRange(listener: RangeListener) {
    this.rangeListeners.add(listener);
    return () => this.rangeListeners.delete(listener);
  }

  onCrosshair(listener: CrosshairListener) {
    this.crosshairListeners.add(listener);
    return () => this.crosshairListeners.delete(listener);
  }

  private broadcastRange(source: ChartKey, range: LogicalRange) {
    this.applying = true;
    try {
      this.charts.forEach(({ chart }, key) => {
        if (key === source) return;
        chart.timeScale().setVisibleLogicalRange(range);
      });
    } finally {
      this.applying = false;
    }
  }

  fitContent() {
    this.charts.forEach(({ chart }) => chart.timeScale().fitContent());
  }
}
