import { useMemo, useState } from 'react';
import FlexLayout from 'flexlayout-react';
import 'flexlayout-react/style/light.css';
import MultiTimeframeChartSet from '../chart-workbench/MultiTimeframeChartSet';
import { useInstrumentSummaryQuery } from '../hooks/api/useInstrumentSummaryQuery';
import { useWorkspaceStore } from '../stores/workspace.store';

const DEFAULT_MODEL = {
  global: {},
  layout: {
    type: 'row',
    children: [
      {
        type: 'tabset',
        weight: 68,
        children: [{ type: 'tab', name: 'Charts', component: 'charts' }],
      },
      {
        type: 'tabset',
        weight: 32,
        children: [
          { type: 'tab', name: 'Symbol Context', component: 'context' },
          { type: 'tab', name: 'Inspection', component: 'inspection' },
          { type: 'tab', name: 'Rule Explanation', component: 'rule' },
          { type: 'tab', name: 'Alert Timeline', component: 'alerts' },
        ],
      },
    ],
  },
};

function SymbolContextPane() {
  const exchangeCode = useWorkspaceStore((s) => s.exchangeCode);
  const tradeDate = useWorkspaceStore((s) => s.tradeDate);
  const instrumentId = useWorkspaceStore((s) => s.activeInstrumentId);
  const q = useInstrumentSummaryQuery({ exchangeCode, tradeDate, instrumentId });
  if (q.isLoading) return <div style={{ padding: 12 }}>Loading context…</div>;
  if (q.error || !q.data) return <div style={{ padding: 12 }}>Failed to load context.</div>;
  return (
    <div style={{ padding: 12, display:'grid', gap:10 }}>
      <div style={{ fontSize: 18, fontWeight: 700 }}>{q.data.identity.symbol}</div>
      <div>Trend: {q.data.trend.state ?? '—'}</div>
      <div>Daily SMA: {q.data.smaStructure?.day ?? '—'}</div>
      <div>Pivot: {q.data.pivots?.latestPivotType ?? '—'}</div>
      <div>Candle: {q.data.candleAnalysis?.currentPattern ?? '—'}</div>
    </div>
  );
}

function InspectionPane() {
  const crosshair = useWorkspaceStore((s) => s.crosshair);
  const visibleRange = useWorkspaceStore((s) => s.visibleRange);
  const hoverSync = useWorkspaceStore((s) => s.hoverSync);
  return (
    <div style={{ padding: 12, display:'grid', gap:8 }}>
      <div style={{ fontSize: 16, fontWeight: 700 }}>Crosshair Inspection</div>
      <div>Source: {crosshair.source ?? '—'}</div>
      <div>Time: {crosshair.time ?? '—'}</div>
      <div>Open: {crosshair.open ?? '—'}</div>
      <div>High: {crosshair.high ?? '—'}</div>
      <div>Low: {crosshair.low ?? '—'}</div>
      <div>Close: {crosshair.close ?? '—'}</div>
      <div>Pivot: {crosshair.pivotType ?? '—'}</div>
      <div>Trend Pivot: {crosshair.trendPivotType ?? '—'}</div>
      <div>Range: {visibleRange.from != null && visibleRange.to != null ? `${visibleRange.from.toFixed(2)} → ${visibleRange.to.toFixed(2)}` : '—'}</div>
      <div>Hover Sync: {hoverSync.time ?? '—'} @ {hoverSync.price ?? '—'}</div>
    </div>
  );
}

export default function DockingWorkspace() {
  const workspaceModelJson = useWorkspaceStore((s) => s.workspaceModelJson);
  const setWorkspaceModelJson = useWorkspaceStore((s) => s.setWorkspaceModelJson);

  const initialModel = useMemo(() => {
    const raw = workspaceModelJson ?? localStorage.getItem('stockanalysis:flexlayout:model');
    try {
      return FlexLayout.Model.fromJson(raw ? JSON.parse(raw) : DEFAULT_MODEL);
    } catch {
      return FlexLayout.Model.fromJson(DEFAULT_MODEL);
    }
  }, []);
  const [model] = useState(initialModel);

  const persistModel = () => {
    const json = JSON.stringify(model.toJson());
    localStorage.setItem('stockanalysis:flexlayout:model', json);
    setWorkspaceModelJson(json);
  };

  const resetModel = () => {
    localStorage.removeItem('stockanalysis:flexlayout:model');
    setWorkspaceModelJson(JSON.stringify(DEFAULT_MODEL));
    window.location.reload();
  };

  const factory = (node: any) => {
    const component = node.getComponent();
    if (component === 'charts') return <MultiTimeframeChartSet />;
    if (component === 'context') return <SymbolContextPane />;
    if (component === 'inspection') return <InspectionPane />;
    if (component === 'rule') return <div style={{ padding: 12 }}>Rule explanation panel shell wired for future rule-debug payloads.</div>;
    if (component === 'alerts') return <div style={{ padding: 12 }}>Alert timeline panel shell wired for future alert/event APIs.</div>;
    return <div>Unknown tab</div>;
  };

  return (
    <div style={{ display:'grid', gridTemplateRows:'auto 1fr', height:'100%' }}>
      <div style={{ display:'flex', gap:10, padding:'8px 12px', borderBottom:'1px solid #243043' }}>
        <button onClick={persistModel}>Save Layout</button>
        <button onClick={resetModel}>Reset Layout</button>
      </div>
      <FlexLayout.Layout model={model} factory={factory} onModelChange={persistModel} />
    </div>
  );
}
