package com.rathore.stockanalysis.common.exchange;

import java.util.Objects;

/**
 * Exchange-specific schema binding used by read APIs.
 *
 * NSE is the primary implementation:
 * - masterSchema = nse_exchange_symbol
 * - marketSchema = market_nse
 * - coreAppSchema = core_app_nse
 *
 * Other exchanges may not yet have a coreAppSchema.
 */
public record ExchangeSchema(
        String exchangeCode,
        String masterSchema,
        String marketSchema,
        String coreAppSchema
) {
    public ExchangeSchema {
        Objects.requireNonNull(exchangeCode, "exchangeCode must not be null");
        Objects.requireNonNull(masterSchema, "masterSchema must not be null");
        Objects.requireNonNull(marketSchema, "marketSchema must not be null");
    }

    public boolean hasCoreAppSchema() {
        return coreAppSchema != null && !coreAppSchema.isBlank();
    }
}
