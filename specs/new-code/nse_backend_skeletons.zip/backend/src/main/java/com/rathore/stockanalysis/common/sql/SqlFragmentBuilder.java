package com.rathore.stockanalysis.common.sql;

import com.rathore.stockanalysis.common.exchange.ExchangeSchema;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Set;

/**
 * Helper for assembling safe SQL fragments for read APIs.
 *
 * Notes:
 * - Schema names come only from ExchangeSchemaRegistry.
 * - Dynamic ORDER BY uses a field allowlist only.
 * - This class is intentionally fragment-oriented; repositories should still
 *   own full query assembly.
 */
@Component
public class SqlFragmentBuilder {

    private static final Set<String> INSTRUMENT_SORT_FIELDS = Set.of(
            "symbol",
            "instrument_id",
            "instrument_type",
            "chart_to_date",
            "trend_state_day",
            "latest_close_day",
            "updated_at"
    );

    private static final Map<String, String> INSTRUMENT_SORT_MAP = Map.of(
            "symbol", "snap.symbol",
            "instrument_id", "snap.instrument_id",
            "instrument_type", "snap.instrument_type",
            "chart_to_date", "snap.chart_to_date",
            "trend_state_day", "snap.trend_state_day",
            "latest_close_day", "snap.latest_close_day",
            "updated_at", "snap.updated_at"
    );

    public String latestBootstrapCte(ExchangeSchema schema) {
        return String.format(
            """latest_bootstrap AS (
                SELECT
                    icb.instrument_id,
                    icb.chart_data_exists,
                    icb.bootstrap_status,
                    icb.chart_data_status,
                    icb.chart_from_date,
                    icb.chart_to_date,
                    icb.chart_timeframes_available_json,
                    icb.reconcile_watermark_date,
                    icb.bootstrap_completed_through_date,
                    icb.last_bootstrap_completed_at,
                    icb.last_reconcile_completed_at,
                    icb.updated_at
                FROM %s.instrument_chart_bootstrap icb
            )""",
            schema.masterSchema()
        );
    }

    public String latestCandleCte(ExchangeSchema schema, String alias, String timeframe) {
        return String.format(
            """%s AS (
                SELECT DISTINCT ON (mc.instrument_id)
                    mc.instrument_id,
                    mc.trade_date,
                    mc.tf_id,
                    mc.bar_start_ts,
                    mc.bar_end_ts,
                    mc.open,
                    mc.high,
                    mc.low,
                    mc.close,
                    mc.volume,
                    mc.updated_at
                FROM %s.market_candle mc
                WHERE mc.timeframe = '%s'
                ORDER BY mc.instrument_id, mc.bar_start_ts DESC, mc.tf_id DESC
            )""",
            alias, schema.marketSchema(), timeframe
        );
    }

    public String latestFastFeatureCte(ExchangeSchema schema, String alias, String timeframe) {
        return String.format(
            """%s AS (
                SELECT DISTINCT ON (ff.instrument_id)
                    ff.instrument_id,
                    ff.bar_start_ts,
                    ff.sma_5,
                    ff.sma_10,
                    ff.sma_20,
                    ff.sma_50,
                    ff.sma_100,
                    ff.sma_200,
                    ff.atr_5,
                    ff.atr_14,
                    ff.atr_20,
                    ff.range_to_atr,
                    ff.body_pct,
                    ff.upper_wick_pct,
                    ff.lower_wick_pct
                FROM %s.market_candle_feature_fast ff
                WHERE ff.timeframe = '%s'
                ORDER BY ff.instrument_id, ff.bar_start_ts DESC, ff.tf_id DESC
            )""",
            alias, schema.marketSchema(), timeframe
        );
    }

    public String latestMarketPivotCte(ExchangeSchema schema, String alias, String timeframe) {
        return String.format(
            """%s AS (
                SELECT DISTINCT ON (mp.instrument_id)
                    mp.instrument_id,
                    mp.bar_start_ts,
                    mp.pivot_type,
                    mp.pivot_confirmed,
                    mp.pivot_price,
                    mp.trend_pivot_type
                FROM %s.market_candle_pivot mp
                WHERE mp.timeframe = '%s'
                ORDER BY mp.instrument_id, mp.bar_start_ts DESC, mp.tf_id DESC
            )""",
            alias, schema.marketSchema(), timeframe
        );
    }

    public String latestCorePivotMetricCte(ExchangeSchema schema, String alias, String timeframe) {
        if (!schema.hasCoreAppSchema()) {
            throw new IllegalStateException("coreAppSchema is required for pivot metric queries");
        }
        return String.format(
            """%s AS (
                SELECT DISTINCT ON (pm.instrument_id)
                    pm.instrument_id,
                    pm.symbol,
                    pm.exchange_code,
                    pm.timeframe,
                    pm.tf_id,
                    pm.pivot,
                    pm.pivot_price,
                    pm.timestamp,
                    pm.pivot_sequence
                FROM %s.pivot_metrics pm
                WHERE pm.timeframe = '%s'
                ORDER BY pm.instrument_id, pm.timestamp DESC, pm.pivot_sequence DESC
            )""",
            alias, schema.coreAppSchema(), timeframe
        );
    }

    public String latestCoreTrendPivotMetricCte(ExchangeSchema schema, String alias, String timeframe) {
        if (!schema.hasCoreAppSchema()) {
            throw new IllegalStateException("coreAppSchema is required for trend pivot metric queries");
        }
        return String.format(
            """%s AS (
                SELECT DISTINCT ON (tpm.instrument_id)
                    tpm.instrument_id,
                    tpm.symbol,
                    tpm.exchange_code,
                    tpm.timeframe,
                    tpm.tf_id,
                    tpm.trend_pivot,
                    tpm.pivot_price,
                    tpm.timestamp,
                    tpm.pivot_sequence
                FROM %s.trend_pivot_metrics tpm
                WHERE tpm.timeframe = '%s'
                ORDER BY tpm.instrument_id, tpm.timestamp DESC, tpm.pivot_sequence DESC
            )""",
            alias, schema.coreAppSchema(), timeframe
        );
    }

    public String instrumentUniverseBaseCte(ExchangeSchema schema) {
        return String.format(
            """instrument_universe AS (
                SELECT
                    im.instrument_id,
                    im.symbol,
                    im.trading_symbol,
                    im.instrument_type,
                    im.is_active,
                    im.source_entity_type,
                    im.source_entity_id
                FROM %s.instrument_master im
                WHERE im.is_active = true
            )""",
            schema.masterSchema()
        );
    }

    public String safeInstrumentOrderBy(String sortField, String direction) {
        String normalizedField = (sortField == null || sortField.isBlank()) ? "symbol" : sortField;
        if (!INSTRUMENT_SORT_FIELDS.contains(normalizedField)) {
            normalizedField = "symbol";
        }
        String normalizedDirection = "desc".equalsIgnoreCase(direction) ? "DESC" : "ASC";
        return " ORDER BY " + INSTRUMENT_SORT_MAP.get(normalizedField) + " " + normalizedDirection + " ";
    }
}
