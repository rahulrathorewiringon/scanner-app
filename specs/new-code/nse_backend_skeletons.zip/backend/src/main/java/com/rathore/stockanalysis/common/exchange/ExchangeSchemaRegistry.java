package com.rathore.stockanalysis.common.exchange;

import org.springframework.stereotype.Component;

import java.util.Locale;
import java.util.Map;

/**
 * Central schema resolver for read APIs.
 *
 * Important:
 * - New code must never use legacy exchange_symbol.* references.
 * - NSE-first implementation explicitly uses:
 *   nse_exchange_symbol + market_nse + core_app_nse
 */
@Component
public class ExchangeSchemaRegistry {

    private static final Map<String, ExchangeSchema> SCHEMAS = Map.of(
            "NSE", new ExchangeSchema("NSE", "nse_exchange_symbol", "market_nse", "core_app_nse"),
            "BSE", new ExchangeSchema("BSE", "bse_exchange_symbol", "market_bse", null),
            "NFO", new ExchangeSchema("NFO", "nfo_exchange_symbol", "market_nfo", "core_app_nfo"),
            "BFO", new ExchangeSchema("BFO", "bfo_exchange_symbol", "market_bfo", null),
            "MCX", new ExchangeSchema("MCX", "mcx_exchange_symbol", "market_mcx", null)
    );

    public ExchangeSchema resolve(String exchangeCode) {
        if (exchangeCode == null || exchangeCode.isBlank()) {
            return SCHEMAS.get("NSE");
        }
        String normalized = exchangeCode.trim().toUpperCase(Locale.ROOT);
        ExchangeSchema schema = SCHEMAS.get(normalized);
        if (schema == null) {
            throw new IllegalArgumentException("Unsupported exchangeCode=" + exchangeCode);
        }
        return schema;
    }

    public String resolveMasterSchema(String exchangeCode) {
        return resolve(exchangeCode).masterSchema();
    }

    public String resolveMarketSchema(String exchangeCode) {
        return resolve(exchangeCode).marketSchema();
    }

    public String resolveCoreAppSchema(String exchangeCode) {
        ExchangeSchema schema = resolve(exchangeCode);
        if (!schema.hasCoreAppSchema()) {
            throw new IllegalStateException(
                    "No coreAppSchema configured for exchangeCode=" + exchangeCode
            );
        }
        return schema.coreAppSchema();
    }
}
