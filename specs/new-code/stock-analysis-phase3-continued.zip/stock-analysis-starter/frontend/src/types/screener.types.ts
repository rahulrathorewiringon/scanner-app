import type { ExchangeCode } from './common.types';

export interface ScreenerFieldOption { value: string; label: string; }
export interface ScreenerFieldDef {
  group: 'instrument' | 'sma' | 'pivot' | 'candle' | 'signal';
  key: string;
  label: string;
  operators: string[];
  valueType: 'single' | 'list' | 'range' | 'relative';
  options?: ScreenerFieldOption[];
}
export interface ScreenerFilterMetadataDto {
  exchangeCode: string;
  timeframes: string[];
  fields: ScreenerFieldDef[];
}
export interface ScreenerFilterGroupDto {
  type: 'group';
  id: string;
  operator: 'AND' | 'OR';
  enabled: boolean;
  children: Array<any>;
}
export interface ScreenerRunRequestDto {
  exchangeCode: ExchangeCode;
  tradeDate: string;
  defaultTimeframe: 'hour' | 'day' | 'week';
  filterTree: ScreenerFilterGroupDto;
  pagination: { pageIndex: number; pageSize: number };
  sort: Array<{ field: string; direction: 'asc' | 'desc' }>;
}
export interface ScreenerResultRowDto {
  instrumentId: number;
  symbol: string;
  sector?: string | null;
  timeframe: string;
  latestClose?: number | null;
  currentCandleType?: string | null;
  latestPivotType?: string | null;
  previousPivotType?: string | null;
  smaAlignmentSummary?: string | null;
  signalSummary?: string | null;
  updatedAt?: string | null;
}
export interface ScreenerRunResponseDto {
  rows: ScreenerResultRowDto[];
  totalRows: number;
  pageIndex: number;
  pageSize: number;
}
export interface ScreenerCountResponseDto { count: number; }
