import FlexLayout from 'flexlayout-react';
import 'flexlayout-react/style/light.css';
import MultiTimeframeChartSet from '../chart-workbench/MultiTimeframeChartSet';
import { useInstrumentSummaryQuery } from '../hooks/api/useInstrumentSummaryQuery';
import { useWorkspaceStore } from '../stores/workspace.store';

const model = FlexLayout.Model.fromJson({
  global: {},
  layout: {
    type: 'row',
    children: [
      {
        type: 'tabset',
        weight: 72,
        children: [{ type: 'tab', name: 'Charts', component: 'charts' }],
      },
      {
        type: 'tabset',
        weight: 28,
        children: [
          { type: 'tab', name: 'Symbol Context', component: 'context' },
          { type: 'tab', name: 'Rule Explanation', component: 'rule' },
          { type: 'tab', name: 'Alert Timeline', component: 'alerts' },
        ],
      },
    ],
  },
});

function SymbolContextPane() {
  const exchangeCode = useWorkspaceStore((s) => s.exchangeCode);
  const tradeDate = useWorkspaceStore((s) => s.tradeDate);
  const instrumentId = useWorkspaceStore((s) => s.activeInstrumentId);
  const q = useInstrumentSummaryQuery({ exchangeCode, tradeDate, instrumentId });
  if (q.isLoading) return <div style={{ padding: 12 }}>Loading context…</div>;
  if (q.error || !q.data) return <div style={{ padding: 12 }}>Failed to load context.</div>;
  return (
    <div style={{ padding: 12, display:'grid', gap:10 }}>
      <div style={{ fontSize: 18, fontWeight: 700 }}>{q.data.identity.symbol}</div>
      <div>Trend: {q.data.trend.state ?? '—'}</div>
      <div>Daily SMA: {q.data.smaStructure?.day ?? '—'}</div>
      <div>Pivot: {q.data.pivots?.latestPivotType ?? '—'}</div>
      <div>Candle: {q.data.candleAnalysis?.currentPattern ?? '—'}</div>
    </div>
  );
}

export default function DockingWorkspace() {
  const factory = (node: FlexLayout.TabNode) => {
    const component = node.getComponent();
    if (component === 'charts') return <MultiTimeframeChartSet />;
    if (component === 'context') return <SymbolContextPane />;
    if (component === 'rule') return <div style={{ padding: 12 }}>Rule explanation panel shell wired for future rule-debug payloads.</div>;
    if (component === 'alerts') return <div style={{ padding: 12 }}>Alert timeline panel shell wired for future alert/event APIs.</div>;
    return <div>Unknown tab</div>;
  };

  return <FlexLayout.Layout model={model} factory={factory} />;
}
