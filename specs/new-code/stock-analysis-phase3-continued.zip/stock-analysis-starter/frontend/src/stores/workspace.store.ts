import { create } from 'zustand';
import type { ExchangeCode, Timeframe, TrendState } from '../types/common.types';

export type VisibleRange = { from?: number; to?: number };
export type CrosshairState = { source?: string | null; time?: string | null };

interface WorkspaceState {
  exchangeCode: ExchangeCode;
  tradeDate: string;
  activeInstrumentId: number;
  symbolQuery: string;
  trendFilter: 'ALL' | TrendState;
  selectedTimeframes: Timeframe[];
  syncEnabled: boolean;
  visibleRange: VisibleRange;
  crosshair: CrosshairState;
  setExchangeCode: (value: ExchangeCode) => void;
  setTradeDate: (value: string) => void;
  setActiveInstrumentId: (value: number) => void;
  setSymbolQuery: (value: string) => void;
  setTrendFilter: (value: 'ALL' | TrendState) => void;
  setSelectedTimeframes: (value: Timeframe[]) => void;
  setSyncEnabled: (value: boolean) => void;
  setVisibleRange: (value: VisibleRange) => void;
  setCrosshair: (value: CrosshairState) => void;
}

export const useWorkspaceStore = create<WorkspaceState>((set) => ({
  exchangeCode: 'NSE',
  tradeDate: '2026-04-17',
  activeInstrumentId: 1,
  symbolQuery: '',
  trendFilter: 'ALL',
  selectedTimeframes: ['week', 'day', 'hour'],
  syncEnabled: true,
  visibleRange: {},
  crosshair: {},
  setExchangeCode: (exchangeCode) => set({ exchangeCode }),
  setTradeDate: (tradeDate) => set({ tradeDate }),
  setActiveInstrumentId: (activeInstrumentId) => set({ activeInstrumentId }),
  setSymbolQuery: (symbolQuery) => set({ symbolQuery }),
  setTrendFilter: (trendFilter) => set({ trendFilter }),
  setSelectedTimeframes: (selectedTimeframes) => set({ selectedTimeframes }),
  setSyncEnabled: (syncEnabled) => set({ syncEnabled }),
  setVisibleRange: (visibleRange) => set({ visibleRange }),
  setCrosshair: (crosshair) => set({ crosshair }),
}));
