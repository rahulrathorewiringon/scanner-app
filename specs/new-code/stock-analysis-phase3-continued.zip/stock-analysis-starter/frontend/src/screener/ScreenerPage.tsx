import { useEffect, useMemo, useState } from 'react';
import { useWorkspaceStore } from '../stores/workspace.store';
import { useScreenerFilterMetadataQuery } from '../hooks/api/useScreenerFilterMetadataQuery';
import { useScreenerCountMutation } from '../hooks/api/useScreenerCountMutation';
import { useScreenerRunMutation } from '../hooks/api/useScreenerRunMutation';
import type { ScreenerRunRequestDto } from '../types/screener.types';
import { Link } from 'react-router-dom';

function baseRequest(exchangeCode: any, tradeDate: string, defaultTimeframe: 'hour'|'day'|'week', field?: string, value?: string): ScreenerRunRequestDto {
  return {
    exchangeCode,
    tradeDate,
    defaultTimeframe,
    filterTree: {
      type: 'group',
      id: 'root',
      operator: 'AND',
      enabled: true,
      children: field && value ? [{
        type: 'condition',
        id: 'cond-1',
        enabled: true,
        fieldGroup: field === 'symbol' ? 'instrument' : field === 'currentCandleType' ? 'candle' : 'pivot',
        field,
        timeframe: defaultTimeframe,
        operator: 'eq',
        value: { kind: 'single', value }
      }] : []
    },
    pagination: { pageIndex: 0, pageSize: 50 },
    sort: [{ field: 'symbol', direction: 'asc' }],
  };
}

export default function ScreenerPage() {
  const exchangeCode = useWorkspaceStore((s) => s.exchangeCode);
  const tradeDate = useWorkspaceStore((s) => s.tradeDate);
  const setActiveInstrumentId = useWorkspaceStore((s) => s.setActiveInstrumentId);
  const [field, setField] = useState('symbol');
  const [value, setValue] = useState('');
  const [timeframe, setTimeframe] = useState<'hour'|'day'|'week'>('day');

  const metadata = useScreenerFilterMetadataQuery(exchangeCode);
  const countMutation = useScreenerCountMutation();
  const runMutation = useScreenerRunMutation();
  const request = useMemo(() => baseRequest(exchangeCode, tradeDate, timeframe, field, value || undefined), [exchangeCode, tradeDate, timeframe, field, value]);

  useEffect(() => {
    countMutation.mutate(request);
  }, [request]);

  return (
    <div style={{ padding: 20, display: 'grid', gap: 16 }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <div>
          <h1 style={{ margin:0 }}>Screener</h1>
          <div style={{ opacity:0.75 }}>Bootstrap wired to /api/screener/filter-metadata, /count, /run</div>
        </div>
        <button onClick={() => runMutation.mutate(request)} style={{ padding:'10px 14px', background:'#2563eb', borderRadius:8 }}>Run Screener</button>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1.1fr 0.9fr', gap:16 }}>
        <div style={{ border:'1px solid #243043', borderRadius:8, background:'#111827', padding:16, display:'grid', gap:12 }}>
          <h3 style={{ marginTop:0 }}>Filter Builder Bootstrap</h3>
          <div style={{ display:'grid', gridTemplateColumns:'180px 160px 1fr', gap:10 }}>
            <select value={timeframe} onChange={(e) => setTimeframe(e.target.value as any)} style={{ padding:8 }}>
              <option value="hour">hour</option>
              <option value="day">day</option>
              <option value="week">week</option>
            </select>
            <select value={field} onChange={(e) => setField(e.target.value)} style={{ padding:8 }}>
              <option value="symbol">symbol</option>
              <option value="currentCandleType">currentCandleType</option>
              <option value="latestPivotType">latestPivotType</option>
            </select>
            <input value={value} onChange={(e) => setValue(e.target.value)} placeholder="Enter value" style={{ padding:8 }} />
          </div>

          <div style={{ fontSize:12, opacity:0.75 }}>
            Available metadata fields: {metadata.data?.fields?.length ?? 0}
          </div>

          <pre style={{ whiteSpace:'pre-wrap', background:'#0b1220', padding:12, borderRadius:8, overflow:'auto' }}>
            {JSON.stringify(request, null, 2)}
          </pre>
        </div>

        <div style={{ border:'1px solid #243043', borderRadius:8, background:'#111827', padding:16, display:'grid', gap:12 }}>
          <h3 style={{ marginTop:0 }}>Execution Summary</h3>
          <div>Count: {countMutation.data?.count ?? '—'}</div>
          <div>Rows: {runMutation.data?.totalRows ?? '—'}</div>
          <div>Exchange: {exchangeCode}</div>
          <div>Trade Date: {tradeDate}</div>
          <Link to="/workspace" style={{ color:'#60a5fa' }}>Open Workspace</Link>
        </div>
      </div>

      <div style={{ border:'1px solid #243043', borderRadius:8, background:'#111827', padding:16 }}>
        <h3 style={{ marginTop:0 }}>Results</h3>
        {runMutation.isPending ? <div>Running screener…</div> : runMutation.error ? <div>Failed to run screener.</div> : (
          <table style={{ width:'100%', borderCollapse:'collapse' }}>
            <thead>
              <tr>
                {['Symbol', 'Sector', 'TF', 'Close', 'Candle', 'Pivot', 'SMA', 'Actions'].map((h) => (
                  <th key={h} style={{ textAlign:'left', padding:'8px 6px', borderBottom:'1px solid #243043' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {runMutation.data?.rows?.map((row) => (
                <tr key={row.instrumentId}>
                  <td style={cell}>{row.symbol}</td>
                  <td style={cell}>{row.sector ?? '—'}</td>
                  <td style={cell}>{row.timeframe}</td>
                  <td style={cell}>{row.latestClose ?? '—'}</td>
                  <td style={cell}>{row.currentCandleType ?? '—'}</td>
                  <td style={cell}>{row.latestPivotType ?? '—'}</td>
                  <td style={cell}>{row.smaAlignmentSummary ?? '—'}</td>
                  <td style={cell}>
                    <Link to="/workspace" onClick={() => setActiveInstrumentId(row.instrumentId)} style={{ color:'#60a5fa' }}>Open</Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
const cell: React.CSSProperties = { padding:'8px 6px', borderBottom:'1px solid #1f2937' };
