import type { IChartApi, LogicalRange } from 'lightweight-charts';

type ChartKey = 'week' | 'day' | 'hour';

export class SynchronizedChartManager {
  private charts = new Map<ChartKey, IChartApi>();
  private applying = false;

  register(key: ChartKey, chart: IChartApi) {
    this.charts.set(key, chart);
    chart.timeScale().subscribeVisibleLogicalRangeChange((range) => {
      if (this.applying || !range) return;
      this.broadcastRange(key, range);
    });
  }

  unregister(key: ChartKey) {
    this.charts.delete(key);
  }

  private broadcastRange(source: ChartKey, range: LogicalRange) {
    this.applying = true;
    try {
      this.charts.forEach((chart, key) => {
        if (key === source) return;
        chart.timeScale().setVisibleLogicalRange(range);
      });
    } finally {
      this.applying = false;
    }
  }

  fitContent() {
    this.charts.forEach((chart) => chart.timeScale().fitContent());
  }
}
