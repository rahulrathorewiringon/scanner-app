import type { ExchangeCode } from './common.types';

export interface WorkspaceLayoutPreset {
  presetId: string;
  userId: string;
  name: string;
  exchangeCode: ExchangeCode;
  layoutJson: Record<string, unknown>;
  createdAt: string;
  updatedAt: string;
}
export interface SaveWorkspaceLayoutPresetRequestDto {
  userId: string;
  name: string;
  exchangeCode: ExchangeCode;
  layoutJson: Record<string, unknown>;
}
