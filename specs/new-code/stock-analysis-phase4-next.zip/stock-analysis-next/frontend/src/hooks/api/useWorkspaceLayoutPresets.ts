import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiDelete, apiGet, apiPost } from '../../lib/apiClient';
import type { SaveWorkspaceLayoutPresetRequestDto, WorkspaceLayoutPreset } from '../../types/workspace.types';

export function useWorkspaceLayoutPresetsQuery(userId: string) {
  return useQuery({
    queryKey: ['workspace-layout-presets', userId],
    queryFn: () => apiGet<WorkspaceLayoutPreset[]>('/api/workspace/layout-presets', { userId }),
    enabled: !!userId,
  });
}

export function useSaveWorkspaceLayoutPresetMutation() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: SaveWorkspaceLayoutPresetRequestDto) => apiPost<WorkspaceLayoutPreset>('/api/workspace/layout-presets', body),
    onSuccess: (_data, vars) => qc.invalidateQueries({ queryKey: ['workspace-layout-presets', vars.userId] }),
  });
}

export function useDeleteWorkspaceLayoutPresetMutation(userId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (presetId: string) => apiDelete<{ deleted: boolean }>('/api/workspace/layout-presets/' + presetId, { userId }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['workspace-layout-presets', userId] }),
  });
}
