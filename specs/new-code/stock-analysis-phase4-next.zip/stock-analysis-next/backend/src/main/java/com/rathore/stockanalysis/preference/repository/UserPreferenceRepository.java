package com.rathore.stockanalysis.preference.repository;

import com.rathore.stockanalysis.preference.dto.*;

import java.util.List;
import java.util.UUID;

public interface UserPreferenceRepository {
    List<SavedScreenerDefinitionDto> listSavedScreeners(String userId);
    SavedScreenerDefinitionDto saveScreener(SaveScreenerRequestDto request);
    void deleteSavedScreener(UUID screenerId, String userId);
    List<WorkspaceLayoutPresetDto> listLayoutPresets(String userId);
    WorkspaceLayoutPresetDto saveLayoutPreset(SaveWorkspaceLayoutPresetRequestDto request);
    void deleteLayoutPreset(UUID presetId, String userId);
    ScreenerBulkActionResponseDto applyBulkAction(ScreenerBulkActionRequestDto request);
}
