package com.rathore.stockanalysis.preference.controller;

import com.rathore.stockanalysis.preference.dto.*;
import com.rathore.stockanalysis.preference.service.UserPreferenceService;
import jakarta.validation.constraints.NotBlank;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api")
@Validated
public class UserPreferenceController {
    private final UserPreferenceService service;

    public UserPreferenceController(UserPreferenceService service) {
        this.service = service;
    }

    @GetMapping("/screener/saved-definitions")
    public List<SavedScreenerDefinitionDto> listSavedScreeners(@RequestParam @NotBlank String userId) {
        return service.listSavedScreeners(userId);
    }

    @PostMapping("/screener/saved-definitions")
    public SavedScreenerDefinitionDto saveScreener(@RequestBody SaveScreenerRequestDto request) {
        return service.saveScreener(request);
    }

    @DeleteMapping("/screener/saved-definitions/{screenerId}")
    public Map<String, Object> deleteSavedScreener(@PathVariable UUID screenerId, @RequestParam String userId) {
        service.deleteSavedScreener(screenerId, userId);
        return Map.of("deleted", true, "screenerId", screenerId);
    }

    @PostMapping("/screener/bulk-actions")
    public ScreenerBulkActionResponseDto bulkAction(@RequestBody ScreenerBulkActionRequestDto request) {
        return service.applyBulkAction(request);
    }

    @GetMapping("/workspace/layout-presets")
    public List<WorkspaceLayoutPresetDto> listLayoutPresets(@RequestParam @NotBlank String userId) {
        return service.listLayoutPresets(userId);
    }

    @PostMapping("/workspace/layout-presets")
    public WorkspaceLayoutPresetDto saveLayoutPreset(@RequestBody SaveWorkspaceLayoutPresetRequestDto request) {
        return service.saveLayoutPreset(request);
    }

    @DeleteMapping("/workspace/layout-presets/{presetId}")
    public Map<String, Object> deleteLayoutPreset(@PathVariable UUID presetId, @RequestParam String userId) {
        service.deleteLayoutPreset(presetId, userId);
        return Map.of("deleted", true, "presetId", presetId);
    }
}
