package com.rathore.stockanalysis.preference.service;

import com.rathore.stockanalysis.preference.dto.*;

import java.util.List;
import java.util.UUID;

public interface UserPreferenceService {
    List<SavedScreenerDefinitionDto> listSavedScreeners(String userId);
    SavedScreenerDefinitionDto saveScreener(SaveScreenerRequestDto request);
    void deleteSavedScreener(UUID screenerId, String userId);
    List<WorkspaceLayoutPresetDto> listLayoutPresets(String userId);
    WorkspaceLayoutPresetDto saveLayoutPreset(SaveWorkspaceLayoutPresetRequestDto request);
    void deleteLayoutPreset(UUID presetId, String userId);
    ScreenerBulkActionResponseDto applyBulkAction(ScreenerBulkActionRequestDto request);
}
