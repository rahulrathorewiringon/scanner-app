package com.rathore.stockanalysis.preference.service.impl;

import com.rathore.stockanalysis.preference.dto.*;
import com.rathore.stockanalysis.preference.repository.UserPreferenceRepository;
import com.rathore.stockanalysis.preference.service.UserPreferenceService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class UserPreferenceServiceImpl implements UserPreferenceService {
    private final UserPreferenceRepository repository;

    public UserPreferenceServiceImpl(UserPreferenceRepository repository) {
        this.repository = repository;
    }

    @Override public List<SavedScreenerDefinitionDto> listSavedScreeners(String userId) { return repository.listSavedScreeners(userId); }
    @Override public SavedScreenerDefinitionDto saveScreener(SaveScreenerRequestDto request) { return repository.saveScreener(request); }
    @Override public void deleteSavedScreener(UUID screenerId, String userId) { repository.deleteSavedScreener(screenerId, userId); }
    @Override public List<WorkspaceLayoutPresetDto> listLayoutPresets(String userId) { return repository.listLayoutPresets(userId); }
    @Override public WorkspaceLayoutPresetDto saveLayoutPreset(SaveWorkspaceLayoutPresetRequestDto request) { return repository.saveLayoutPreset(request); }
    @Override public void deleteLayoutPreset(UUID presetId, String userId) { repository.deleteLayoutPreset(presetId, userId); }
    @Override public ScreenerBulkActionResponseDto applyBulkAction(ScreenerBulkActionRequestDto request) { return repository.applyBulkAction(request); }
}
