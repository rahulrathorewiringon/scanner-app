package com.rathore.stockanalysis.preference.repository.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rathore.stockanalysis.preference.dto.*;
import com.rathore.stockanalysis.preference.repository.UserPreferenceRepository;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.*;

@Repository
public class UserPreferenceRepositoryImpl implements UserPreferenceRepository {
    private final NamedParameterJdbcTemplate jdbcTemplate;
    private final ObjectMapper objectMapper;

    public UserPreferenceRepositoryImpl(NamedParameterJdbcTemplate jdbcTemplate, ObjectMapper objectMapper) {
        this.jdbcTemplate = jdbcTemplate;
        this.objectMapper = objectMapper;
    }

    @Override
    public List<SavedScreenerDefinitionDto> listSavedScreeners(String userId) {
        return jdbcTemplate.query("""
                SELECT screener_id, user_id, name, exchange_code, trade_date, default_timeframe, filter_tree, sort_spec, page_size, created_at, updated_at
                FROM app_ui.saved_screener_definition
                WHERE user_id = :userId
                ORDER BY updated_at DESC
                """, new MapSqlParameterSource("userId", userId), (rs, n) -> mapSavedScreener(rs));
    }

    @Override
    public SavedScreenerDefinitionDto saveScreener(SaveScreenerRequestDto request) {
        UUID id = UUID.randomUUID();
        jdbcTemplate.update("""
                INSERT INTO app_ui.saved_screener_definition
                (screener_id, user_id, name, exchange_code, trade_date, default_timeframe, filter_tree, sort_spec, page_size)
                VALUES (:screenerId, :userId, :name, :exchangeCode, :tradeDate, :defaultTimeframe, CAST(:filterTree AS jsonb), CAST(:sortSpec AS jsonb), :pageSize)
                """, new MapSqlParameterSource()
                .addValue("screenerId", id)
                .addValue("userId", request.userId())
                .addValue("name", request.name())
                .addValue("exchangeCode", request.exchangeCode())
                .addValue("tradeDate", LocalDate.parse(request.tradeDate()))
                .addValue("defaultTimeframe", request.defaultTimeframe())
                .addValue("filterTree", toJson(request.filterTree()))
                .addValue("sortSpec", toJson(request.sortSpec()))
                .addValue("pageSize", request.pageSize()));
        return listSavedScreeners(request.userId()).stream().filter(s -> s.screenerId().equals(id)).findFirst().orElseThrow();
    }

    @Override
    public void deleteSavedScreener(UUID screenerId, String userId) {
        jdbcTemplate.update("DELETE FROM app_ui.saved_screener_definition WHERE screener_id = :id AND user_id = :userId",
                new MapSqlParameterSource().addValue("id", screenerId).addValue("userId", userId));
    }

    @Override
    public List<WorkspaceLayoutPresetDto> listLayoutPresets(String userId) {
        return jdbcTemplate.query("""
                SELECT preset_id, user_id, name, exchange_code, layout_json, created_at, updated_at
                FROM app_ui.workspace_layout_preset
                WHERE user_id = :userId
                ORDER BY updated_at DESC
                """, new MapSqlParameterSource("userId", userId), (rs, n) -> mapLayoutPreset(rs));
    }

    @Override
    public WorkspaceLayoutPresetDto saveLayoutPreset(SaveWorkspaceLayoutPresetRequestDto request) {
        UUID id = UUID.randomUUID();
        jdbcTemplate.update("""
                INSERT INTO app_ui.workspace_layout_preset
                (preset_id, user_id, name, exchange_code, layout_json)
                VALUES (:presetId, :userId, :name, :exchangeCode, CAST(:layoutJson AS jsonb))
                """, new MapSqlParameterSource()
                .addValue("presetId", id)
                .addValue("userId", request.userId())
                .addValue("name", request.name())
                .addValue("exchangeCode", request.exchangeCode())
                .addValue("layoutJson", toJson(request.layoutJson())));
        return listLayoutPresets(request.userId()).stream().filter(s -> s.presetId().equals(id)).findFirst().orElseThrow();
    }

    @Override
    public void deleteLayoutPreset(UUID presetId, String userId) {
        jdbcTemplate.update("DELETE FROM app_ui.workspace_layout_preset WHERE preset_id = :id AND user_id = :userId",
                new MapSqlParameterSource().addValue("id", presetId).addValue("userId", userId));
    }

    @Override
    public ScreenerBulkActionResponseDto applyBulkAction(ScreenerBulkActionRequestDto request) {
        UUID id = UUID.randomUUID();
        int acceptedCount = request.instrumentIds() == null ? 0 : request.instrumentIds().size();
        jdbcTemplate.update("""
                INSERT INTO app_ui.screener_bulk_action_audit
                (action_id, user_id, action_type, instrument_ids, payload, accepted_count)
                VALUES (:actionId, :userId, :actionType, CAST(:instrumentIds AS jsonb), CAST(:payload AS jsonb), :acceptedCount)
                """, new MapSqlParameterSource()
                .addValue("actionId", id)
                .addValue("userId", request.userId())
                .addValue("actionType", request.actionType())
                .addValue("instrumentIds", toJson(request.instrumentIds()))
                .addValue("payload", toJson(request.payload()))
                .addValue("acceptedCount", acceptedCount));
        return new ScreenerBulkActionResponseDto(id, request.actionType(), acceptedCount, "Accepted " + acceptedCount + " instruments for action " + request.actionType());
    }

    private SavedScreenerDefinitionDto mapSavedScreener(ResultSet rs) throws SQLException {
        return new SavedScreenerDefinitionDto(
                rs.getObject("screener_id", UUID.class),
                rs.getString("user_id"),
                rs.getString("name"),
                rs.getString("exchange_code"),
                String.valueOf(rs.getDate("trade_date").toLocalDate()),
                rs.getString("default_timeframe"),
                fromJsonMap(rs.getString("filter_tree")),
                fromJson(rs.getString("sort_spec")),
                rs.getInt("page_size"),
                rs.getTimestamp("created_at").toInstant().toString(),
                rs.getTimestamp("updated_at").toInstant().toString()
        );
    }

    private WorkspaceLayoutPresetDto mapLayoutPreset(ResultSet rs) throws SQLException {
        return new WorkspaceLayoutPresetDto(
                rs.getObject("preset_id", UUID.class),
                rs.getString("user_id"),
                rs.getString("name"),
                rs.getString("exchange_code"),
                fromJsonMap(rs.getString("layout_json")),
                rs.getTimestamp("created_at").toInstant().toString(),
                rs.getTimestamp("updated_at").toInstant().toString()
        );
    }

    private String toJson(Object value) {
        try { return objectMapper.writeValueAsString(value); }
        catch (JsonProcessingException e) { throw new RuntimeException(e); }
    }

    private Map<String, Object> fromJsonMap(String value) {
        try { return objectMapper.readValue(value, new TypeReference<Map<String, Object>>() {}); }
        catch (Exception e) { throw new RuntimeException(e); }
    }

    private Object fromJson(String value) {
        try { return objectMapper.readValue(value, Object.class); }
        catch (Exception e) { throw new RuntimeException(e); }
    }
}
