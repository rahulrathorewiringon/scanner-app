CREATE SCHEMA IF NOT EXISTS app_ui;

CREATE TABLE IF NOT EXISTS app_ui.saved_screener_definition (
    screener_id UUID PRIMARY KEY,
    user_id TEXT NOT NULL,
    name TEXT NOT NULL,
    exchange_code TEXT NOT NULL,
    trade_date DATE NOT NULL,
    default_timeframe TEXT NOT NULL,
    filter_tree JSONB NOT NULL,
    sort_spec JSONB NOT NULL,
    page_size INTEGER NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT now(),
    updated_at TIMESTAMP NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_saved_screener_user_id
    ON app_ui.saved_screener_definition (user_id, updated_at DESC);

CREATE TABLE IF NOT EXISTS app_ui.workspace_layout_preset (
    preset_id UUID PRIMARY KEY,
    user_id TEXT NOT NULL,
    name TEXT NOT NULL,
    exchange_code TEXT NOT NULL,
    layout_json JSONB NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT now(),
    updated_at TIMESTAMP NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_workspace_layout_user_id
    ON app_ui.workspace_layout_preset (user_id, updated_at DESC);

CREATE TABLE IF NOT EXISTS app_ui.screener_bulk_action_audit (
    action_id UUID PRIMARY KEY,
    user_id TEXT NOT NULL,
    action_type TEXT NOT NULL,
    instrument_ids JSONB NOT NULL,
    payload JSONB,
    accepted_count INTEGER NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT now()
);
