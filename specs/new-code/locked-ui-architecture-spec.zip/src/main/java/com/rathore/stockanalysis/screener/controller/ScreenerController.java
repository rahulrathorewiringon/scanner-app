package com.rathore.stockanalysis.screener.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/screener")
public class ScreenerController {
}
