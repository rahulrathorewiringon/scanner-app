package com.rathore.stockanalysis.screener.dto;

public final class ScreenerDtos {
    private ScreenerDtos() {}
}
