package com.rathore.stockanalysis.watchlist.dto;

public final class WatchlistDtos {
    private WatchlistDtos() {}
}
