package com.rathore.stockanalysis.screener.service;

public interface ScreenerService {
}
