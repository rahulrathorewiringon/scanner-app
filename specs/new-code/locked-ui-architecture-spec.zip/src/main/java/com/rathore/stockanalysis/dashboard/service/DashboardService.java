package com.rathore.stockanalysis.dashboard.service;

public interface DashboardService {
}
