package com.rathore.stockanalysis.instrument.service;

public interface InstrumentService {
}
