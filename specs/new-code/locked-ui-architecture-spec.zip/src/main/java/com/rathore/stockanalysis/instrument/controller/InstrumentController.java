package com.rathore.stockanalysis.instrument.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/instrument")
public class InstrumentController {
}
