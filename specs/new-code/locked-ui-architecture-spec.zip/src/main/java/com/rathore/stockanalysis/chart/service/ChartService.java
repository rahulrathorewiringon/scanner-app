package com.rathore.stockanalysis.chart.service;

public interface ChartService {
}
