package com.rathore.stockanalysis.preference.service.impl;

import com.rathore.stockanalysis.preference.dto.*;
import com.rathore.stockanalysis.preference.repository.UserPreferenceRepository;
import com.rathore.stockanalysis.preference.service.UserPreferenceService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class UserPreferenceServiceImpl implements UserPreferenceService {
    private final UserPreferenceRepository repository;

    public UserPreferenceServiceImpl(UserPreferenceRepository repository) {
        this.repository = repository;
    }

    @Override public List<SavedScreenerDefinitionDto> listSavedScreeners(String userId) { return repository.listSavedScreeners(userId); }
    @Override public List<SavedScreenerDefinitionDto> listSharedScreeners(String userId) { return repository.listSharedScreeners(userId); }
    @Override public SavedScreenerDefinitionDto saveScreener(SaveScreenerRequestDto request) { return repository.saveScreener(request); }
    @Override public SavedScreenerDefinitionDto updateScreener(UpdateScreenerRequestDto request) { return repository.updateScreener(request); }
    @Override public void deleteSavedScreener(UUID screenerId, String userId) { repository.deleteSavedScreener(screenerId, userId); }
    @Override public List<SavedScreenerTagDto> listScreenerTags(UUID screenerId, String userId) { return repository.listScreenerTags(screenerId, userId); }
    @Override public List<SavedScreenerTagDto> replaceScreenerTags(UUID screenerId, String userId, List<String> tags) { return repository.replaceScreenerTags(screenerId, userId, tags); }
    @Override public List<SavedScreenerShareDto> listScreenerShares(UUID screenerId, String ownerUserId) { return repository.listScreenerShares(screenerId, ownerUserId); }
    @Override public SavedScreenerShareDto saveScreenerShare(SaveScreenerShareRequestDto request) { return repository.saveScreenerShare(request); }
    @Override public SavedScreenerShareDto updateScreenerSharePermission(SaveScreenerShareRequestDto request) { return repository.updateScreenerSharePermission(request); }
    @Override public void deleteScreenerShare(UUID screenerId, String ownerUserId, String sharedWithUserId) { repository.deleteScreenerShare(screenerId, ownerUserId, sharedWithUserId); }
    @Override public List<WorkspaceLayoutPresetDto> listLayoutPresets(String userId) { return repository.listLayoutPresets(userId); }
    @Override public List<WorkspaceLayoutPresetDto> listSharedLayoutPresets(String userId) { return repository.listSharedLayoutPresets(userId); }
    @Override public WorkspaceLayoutPresetDto saveLayoutPreset(SaveWorkspaceLayoutPresetRequestDto request) { return repository.saveLayoutPreset(request); }
    @Override public WorkspaceLayoutPresetDto updateLayoutPreset(UpdateWorkspaceLayoutPresetRequestDto request) { return repository.updateLayoutPreset(request); }
    @Override public WorkspaceLayoutPresetDto markDefaultLayoutPreset(UUID presetId, String userId) { repository.markDefaultLayoutPreset(presetId, userId); return repository.listLayoutPresets(userId).stream().filter(p -> p.presetId().equals(presetId)).findFirst().orElse(null); }
    @Override public WorkspaceLayoutPresetDto markFavoriteLayoutPreset(UUID presetId, String userId, boolean favorite) { repository.markFavoriteLayoutPreset(presetId, userId, favorite); return repository.listLayoutPresets(userId).stream().filter(p -> p.presetId().equals(presetId)).findFirst().orElse(null); }
    @Override public void deleteLayoutPreset(UUID presetId, String userId) { repository.deleteLayoutPreset(presetId, userId); }
    @Override public List<WorkspaceLayoutPresetShareDto> listLayoutPresetShares(UUID presetId, String ownerUserId) { return repository.listLayoutPresetShares(presetId, ownerUserId); }
    @Override public WorkspaceLayoutPresetShareDto saveLayoutPresetShare(SaveWorkspaceLayoutPresetShareRequestDto request) { return repository.saveLayoutPresetShare(request); }
    @Override public WorkspaceLayoutPresetShareDto updateLayoutPresetSharePermission(SaveWorkspaceLayoutPresetShareRequestDto request) { return repository.updateLayoutPresetSharePermission(request); }
    @Override public void deleteLayoutPresetShare(UUID presetId, String ownerUserId, String sharedWithUserId) { repository.deleteLayoutPresetShare(presetId, ownerUserId, sharedWithUserId); }
    @Override public ScreenerBulkActionResponseDto applyBulkAction(ScreenerBulkActionRequestDto request) { return repository.applyBulkAction(request); }
}
