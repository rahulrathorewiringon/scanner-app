import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import apiClient from '../../lib/apiClient';

export function useSharedScreeners(userId: string) {
  return useQuery({
    queryKey: ['shared-screeners', userId],
    queryFn: async () => (await apiClient.get('/api/screener/shared-definitions', { params: { userId } })).data,
  });
}

export function useUpdateSavedScreenerSharePermission() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (payload: { screenerId: number; actorUserId: string; sharedWithUserId: string; permissionCode: string }) =>
      (await apiClient.put(`/api/screener/saved-definitions/${payload.screenerId}/shares`, payload)).data,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['shared-screeners'] }),
  });
}
