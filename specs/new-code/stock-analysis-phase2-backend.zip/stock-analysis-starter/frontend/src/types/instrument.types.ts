import type { ExchangeCode, Timeframe, TrendState } from './common.types';

export interface InstrumentRowDto {
  instrumentId: number;
  symbol: string;
  instrumentType: string;
  sector?: string | null;
  exchangeCode: ExchangeCode;
  latestTradeDate?: string | null;
  chartDataExists: boolean;
  chartTimeframesAvailable: Timeframe[];
  bootstrapStatus: string;
  trendState?: TrendState | null;
  currentCandlePattern?: string | null;
  latestPivotType?: string | null;
  smaStructure?: string | null;
  updatedAt?: string | null;
}

export interface InstrumentSearchResponseDto {
  rows: InstrumentRowDto[];
  totalRows: number;
  pageIndex: number;
  pageSize: number;
}

export interface InstrumentSummaryDto {
  identity: {
    instrumentId: number;
    symbol: string;
    exchangeCode: ExchangeCode;
  };
  dataAvailability: {
    chartDataExists: boolean;
    bootstrapStatus: string;
    chartTimeframesAvailable: Timeframe[];
  };
  trend: {
    state?: TrendState | null;
    timeframe?: Timeframe | null;
  };
}
