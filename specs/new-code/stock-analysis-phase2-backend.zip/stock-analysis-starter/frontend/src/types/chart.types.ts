import type { ExchangeCode, Timeframe } from './common.types';

export interface ChartCandleDto {
  barStartTs: string;
  barEndTs: string;
  tradeDate: string;
  tfId: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number | null;
}

export interface ChartSeriesDto {
  timeframe: Timeframe;
  candles: ChartCandleDto[];
}

export interface MultiTimeframeChartsDto {
  instrumentId: number;
  exchangeCode: ExchangeCode;
  symbol: string;
  series: {
    week?: ChartSeriesDto | null;
    day?: ChartSeriesDto | null;
    hour?: ChartSeriesDto | null;
  };
}
