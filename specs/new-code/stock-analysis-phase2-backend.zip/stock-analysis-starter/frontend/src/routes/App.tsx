import { Navigate, Route, Routes } from 'react-router-dom';
import AppShell from '../app-shell/AppShell';
import { useDashboardOverviewQuery } from '../hooks/api/useDashboardOverviewQuery';
import DockingWorkspace from '../workspace-layout/DockingWorkspace';
import { useWorkspaceStore } from '../stores/workspace.store';

function DashboardPage() {
  const exchangeCode = useWorkspaceStore((s) => s.exchangeCode);
  const tradeDate = useWorkspaceStore((s) => s.tradeDate);
  const { data, isLoading } = useDashboardOverviewQuery({ exchangeCode, tradeDate, timeframe: 'day' });

  return (
    <div style={{ padding: 20 }}>
      <h1>Dashboard</h1>
      {isLoading ? <div>Loading…</div> : <pre>{JSON.stringify(data, null, 2)}</pre>}
    </div>
  );
}

function Placeholder({ title }: { title: string }) {
  return <div style={{ padding: 20 }}><h1>{title}</h1><p>Starter module scaffold.</p></div>;
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<AppShell />}>
        <Route index element={<DashboardPage />} />
        <Route path="workspace" element={<DockingWorkspace />} />
        <Route path="watchlists" element={<Placeholder title="Watchlists" />} />
        <Route path="alerts" element={<Placeholder title="Alerts" />} />
        <Route path="rule-lab" element={<Placeholder title="Rule Lab" />} />
        <Route path="snapshot-inspector" element={<Placeholder title="Snapshot Inspector" />} />
        <Route path="admin" element={<Placeholder title="Admin Control Plane" />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}
