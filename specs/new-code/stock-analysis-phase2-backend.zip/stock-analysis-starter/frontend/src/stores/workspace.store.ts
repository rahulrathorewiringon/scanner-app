import { create } from 'zustand';

interface WorkspaceState {
  exchangeCode: 'NSE' | 'BSE' | 'NFO' | 'BFO' | 'MCX';
  tradeDate: string;
  activeInstrumentId: number;
  setExchangeCode: (value: WorkspaceState['exchangeCode']) => void;
  setTradeDate: (value: string) => void;
  setActiveInstrumentId: (value: number) => void;
}

export const useWorkspaceStore = create<WorkspaceState>((set) => ({
  exchangeCode: 'NSE',
  tradeDate: '2026-04-17',
  activeInstrumentId: 1,
  setExchangeCode: (exchangeCode) => set({ exchangeCode }),
  setTradeDate: (tradeDate) => set({ tradeDate }),
  setActiveInstrumentId: (activeInstrumentId) => set({ activeInstrumentId }),
}));
