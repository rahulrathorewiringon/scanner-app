import ChartPane from './ChartPane';
import { useWorkspaceStore } from '../stores/workspace.store';
import { useMultiTimeframeChartsQuery } from '../hooks/api/useMultiTimeframeChartsQuery';

export default function MultiTimeframeChartSet() {
  const exchangeCode = useWorkspaceStore((s) => s.exchangeCode);
  const instrumentId = useWorkspaceStore((s) => s.activeInstrumentId);
  const { data, isLoading, error } = useMultiTimeframeChartsQuery({ exchangeCode, instrumentId });

  if (isLoading) return <div style={{ padding: 12 }}>Loading charts…</div>;
  if (error) return <div style={{ padding: 12 }}>Failed to load charts.</div>;

  return (
    <div style={{ display: 'grid', gap: 12, padding: 12 }}>
      <ChartPane title="Weekly" series={data?.series.week} />
      <ChartPane title="Daily" series={data?.series.day} />
      <ChartPane title="Hourly" series={data?.series.hour} />
    </div>
  );
}
