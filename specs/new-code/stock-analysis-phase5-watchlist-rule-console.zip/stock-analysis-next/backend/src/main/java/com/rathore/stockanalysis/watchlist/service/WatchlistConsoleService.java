package com.rathore.stockanalysis.watchlist.service;

import com.rathore.stockanalysis.watchlist.dto.WatchlistDtos;

import java.util.List;
import java.util.UUID;

public interface WatchlistConsoleService {
    List<WatchlistDtos.WatchlistDefinitionDto> listWatchlists(String userId);
    List<WatchlistDtos.WatchlistItemDto> listWatchlistItems(String userId, UUID watchlistId);
    List<WatchlistDtos.AlertRuleDto> listAlertRules(String userId);
    void updateAlertRuleStatus(UUID alertRuleId, String userId, String status);
    List<WatchlistDtos.WatchlistGenerationRuleDto> listRules(String userId);
    WatchlistDtos.WatchlistGenerationRuleDto saveRule(WatchlistDtos.SaveWatchlistGenerationRuleRequestDto request);
    WatchlistDtos.WatchlistGenerationRuleDto updateRule(WatchlistDtos.UpdateWatchlistGenerationRuleRequestDto request);
    void deleteRule(UUID ruleId, String userId);
    WatchlistDtos.GenerateWatchlistFromRuleResponseDto generateRule(UUID ruleId, String userId);
}
