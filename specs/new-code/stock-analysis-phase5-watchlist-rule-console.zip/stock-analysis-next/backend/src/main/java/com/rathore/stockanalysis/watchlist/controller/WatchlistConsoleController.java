package com.rathore.stockanalysis.watchlist.controller;

import com.rathore.stockanalysis.watchlist.dto.WatchlistDtos;
import com.rathore.stockanalysis.watchlist.service.WatchlistConsoleService;
import jakarta.validation.constraints.NotBlank;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api")
@Validated
public class WatchlistConsoleController {
    private final WatchlistConsoleService service;

    public WatchlistConsoleController(WatchlistConsoleService service) {
        this.service = service;
    }

    @GetMapping("/watchlists")
    public List<WatchlistDtos.WatchlistDefinitionDto> listWatchlists(@RequestParam @NotBlank String userId) {
        return service.listWatchlists(userId);
    }

    @GetMapping("/watchlists/{watchlistId}/items")
    public List<WatchlistDtos.WatchlistItemDto> listWatchlistItems(@PathVariable UUID watchlistId, @RequestParam @NotBlank String userId) {
        return service.listWatchlistItems(userId, watchlistId);
    }

    @GetMapping("/watchlists/rules")
    public List<WatchlistDtos.WatchlistGenerationRuleDto> listRules(@RequestParam @NotBlank String userId) {
        return service.listRules(userId);
    }

    @PostMapping("/watchlists/rules")
    public WatchlistDtos.WatchlistGenerationRuleDto saveRule(@RequestBody WatchlistDtos.SaveWatchlistGenerationRuleRequestDto request) {
        return service.saveRule(request);
    }

    @PutMapping("/watchlists/rules/{ruleId}")
    public WatchlistDtos.WatchlistGenerationRuleDto updateRule(@PathVariable UUID ruleId, @RequestBody WatchlistDtos.UpdateWatchlistGenerationRuleRequestDto request) {
        return service.updateRule(new WatchlistDtos.UpdateWatchlistGenerationRuleRequestDto(ruleId, request.userId(), request.watchlistId(), request.name(), request.exchangeCode(), request.ruleType(), request.ruleDefinition(), request.isEnabled()));
    }

    @DeleteMapping("/watchlists/rules/{ruleId}")
    public Map<String, Object> deleteRule(@PathVariable UUID ruleId, @RequestParam @NotBlank String userId) {
        service.deleteRule(ruleId, userId);
        return Map.of("deleted", true, "ruleId", ruleId);
    }

    @PostMapping("/watchlists/rules/{ruleId}/generate")
    public WatchlistDtos.GenerateWatchlistFromRuleResponseDto generateRule(@PathVariable UUID ruleId, @RequestParam @NotBlank String userId) {
        return service.generateRule(ruleId, userId);
    }

    @GetMapping("/alerts/rules")
    public List<WatchlistDtos.AlertRuleDto> listAlerts(@RequestParam @NotBlank String userId) {
        return service.listAlertRules(userId);
    }

    @PutMapping("/alerts/rules/{alertRuleId}/status")
    public Map<String, Object> updateAlertStatus(@PathVariable UUID alertRuleId, @RequestParam @NotBlank String userId, @RequestParam @NotBlank String status) {
        service.updateAlertRuleStatus(alertRuleId, userId, status);
        return Map.of("updated", true, "alertRuleId", alertRuleId, "status", status);
    }
}
