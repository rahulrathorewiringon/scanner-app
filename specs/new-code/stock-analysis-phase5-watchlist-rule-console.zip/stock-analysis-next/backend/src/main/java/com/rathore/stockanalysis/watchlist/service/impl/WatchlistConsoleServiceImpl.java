package com.rathore.stockanalysis.watchlist.service.impl;

import com.rathore.stockanalysis.watchlist.dto.WatchlistDtos;
import com.rathore.stockanalysis.watchlist.repository.WatchlistConsoleRepository;
import com.rathore.stockanalysis.watchlist.service.WatchlistConsoleService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class WatchlistConsoleServiceImpl implements WatchlistConsoleService {
    private final WatchlistConsoleRepository repository;

    public WatchlistConsoleServiceImpl(WatchlistConsoleRepository repository) {
        this.repository = repository;
    }

    @Override public List<WatchlistDtos.WatchlistDefinitionDto> listWatchlists(String userId) { return repository.listWatchlists(userId); }
    @Override public List<WatchlistDtos.WatchlistItemDto> listWatchlistItems(String userId, UUID watchlistId) { return repository.listWatchlistItems(userId, watchlistId); }
    @Override public List<WatchlistDtos.AlertRuleDto> listAlertRules(String userId) { return repository.listAlertRules(userId); }
    @Override public void updateAlertRuleStatus(UUID alertRuleId, String userId, String status) { repository.updateAlertRuleStatus(alertRuleId, userId, status); }
    @Override public List<WatchlistDtos.WatchlistGenerationRuleDto> listRules(String userId) { return repository.listWatchlistGenerationRules(userId); }
    @Override public WatchlistDtos.WatchlistGenerationRuleDto saveRule(WatchlistDtos.SaveWatchlistGenerationRuleRequestDto request) { return repository.saveWatchlistGenerationRule(request); }
    @Override public WatchlistDtos.WatchlistGenerationRuleDto updateRule(WatchlistDtos.UpdateWatchlistGenerationRuleRequestDto request) { return repository.updateWatchlistGenerationRule(request); }
    @Override public void deleteRule(UUID ruleId, String userId) { repository.deleteWatchlistGenerationRule(ruleId, userId); }
    @Override public WatchlistDtos.GenerateWatchlistFromRuleResponseDto generateRule(UUID ruleId, String userId) { return repository.generateWatchlistFromRule(ruleId, userId); }
}
