package com.rathore.stockanalysis.watchlist.repository;

import com.rathore.stockanalysis.watchlist.dto.WatchlistDtos;

import java.util.List;
import java.util.UUID;

public interface WatchlistConsoleRepository {
    List<WatchlistDtos.WatchlistDefinitionDto> listWatchlists(String userId);
    List<WatchlistDtos.WatchlistItemDto> listWatchlistItems(String userId, UUID watchlistId);
    List<WatchlistDtos.AlertRuleDto> listAlertRules(String userId);
    List<WatchlistDtos.WatchlistGenerationRuleDto> listWatchlistGenerationRules(String userId);
    WatchlistDtos.WatchlistGenerationRuleDto saveWatchlistGenerationRule(WatchlistDtos.SaveWatchlistGenerationRuleRequestDto request);
    WatchlistDtos.WatchlistGenerationRuleDto updateWatchlistGenerationRule(WatchlistDtos.UpdateWatchlistGenerationRuleRequestDto request);
    void deleteWatchlistGenerationRule(UUID ruleId, String userId);
    WatchlistDtos.GenerateWatchlistFromRuleResponseDto generateWatchlistFromRule(UUID ruleId, String userId);
    void updateAlertRuleStatus(UUID alertRuleId, String userId, String status);
}
