import { useMemo, useState } from 'react';
import { useWorkspaceStore } from '../stores/workspace.store';
import { useGenerateWatchlistRuleMutation, useSaveWatchlistRuleMutation, useUpdateWatchlistRuleMutation, useWatchlistItemsQuery, useWatchlistRulesQuery, useWatchlistsQuery, useDeleteWatchlistRuleMutation } from '../hooks/api/useWatchlistConsole';

export default function WatchlistsPage() {
  const userId = useWorkspaceStore((s) => s.userId);
  const exchangeCode = useWorkspaceStore((s) => s.exchangeCode);
  const tradeDate = useWorkspaceStore((s) => s.tradeDate);
  const watchlists = useWatchlistsQuery(userId);
  const rules = useWatchlistRulesQuery(userId);
  const saveRule = useSaveWatchlistRuleMutation(userId);
  const updateRule = useUpdateWatchlistRuleMutation(userId);
  const deleteRule = useDeleteWatchlistRuleMutation(userId);
  const generateRule = useGenerateWatchlistRuleMutation(userId);
  const [selectedWatchlistId, setSelectedWatchlistId] = useState<string | null>(null);
  const [editingRuleId, setEditingRuleId] = useState<string | null>(null);
  const items = useWatchlistItemsQuery(userId, selectedWatchlistId);
  const [name, setName] = useState('Momentum Daily');
  const [filterJson, setFilterJson] = useState('{"type":"group","id":"root","operator":"AND","enabled":true,"children":[]}');

  const selectedWatchlist = useMemo(() => (watchlists.data ?? [])[0]?.watchlistId ?? null, [watchlists.data]);
  const effectiveWatchlistId = selectedWatchlistId ?? selectedWatchlist;

  const saveCurrentRule = () => {
    if (!effectiveWatchlistId) return;
    const payload = {
      tradeDate,
      defaultTimeframe: 'day',
      pageSize: 200,
      filterTree: JSON.parse(filterJson),
    } as Record<string, unknown>;
    if (editingRuleId) {
      updateRule.mutate({ ruleId: editingRuleId, userId, watchlistId: effectiveWatchlistId, name, exchangeCode, ruleType: 'JSON_SCREENER_FILTER', ruleDefinition: payload, isEnabled: true });
      setEditingRuleId(null);
    } else {
      saveRule.mutate({ userId, watchlistId: effectiveWatchlistId, name, exchangeCode, ruleType: 'JSON_SCREENER_FILTER', ruleDefinition: payload, isEnabled: true });
    }
  };

  return <div style={{ padding:20, display:'grid', gap:16 }}>
    <div><h1 style={{ margin:0 }}>Watchlists Console</h1><div style={{ opacity:0.75 }}>JSON-based watchlist generation rule engine + domain watchlist items</div></div>
    <div style={{ display:'grid', gridTemplateColumns:'0.8fr 1.2fr 1fr', gap:16 }}>
      <section style={card}><h3>Watchlists</h3>{(watchlists.data ?? []).map((w) => <button key={w.watchlistId} onClick={() => setSelectedWatchlistId(w.watchlistId)} style={{ display:'block', width:'100%', textAlign:'left', marginBottom:8 }}>{w.name} · {w.watchlistType}</button>)}</section>
      <section style={card}><h3>Watchlist Items</h3>{(items.data ?? []).map((i) => <div key={i.watchlistItemId} style={row}><strong>{i.symbol ?? i.instrumentId}</strong><span>{i.sourceRuleId ? 'RULE' : 'MANUAL'}</span></div>)}</section>
      <section style={card}><h3>Rule Engine</h3><input value={name} onChange={(e) => setName(e.target.value)} placeholder='Rule name' style={input}/><textarea value={filterJson} onChange={(e) => setFilterJson(e.target.value)} rows={10} style={{ ...input, fontFamily:'monospace' }} /><div style={{ display:'flex', gap:8, flexWrap:'wrap' }}><button onClick={saveCurrentRule}>{editingRuleId ? 'Update Rule' : 'Save Rule'}</button>{editingRuleId && <button onClick={() => setEditingRuleId(null)}>Cancel</button>}</div><div style={{ marginTop:12 }}><h4>Saved Rules</h4>{(rules.data ?? []).map((r) => <div key={r.ruleId} style={{ border:'1px solid #243043', borderRadius:8, padding:8, marginBottom:8 }}><strong>{r.name}</strong><div>{r.ruleType} · {r.isEnabled ? 'Enabled' : 'Disabled'}</div><div style={{ display:'flex', gap:8, flexWrap:'wrap', marginTop:8 }}><button onClick={() => { setEditingRuleId(r.ruleId); setName(r.name); setFilterJson(JSON.stringify(r.ruleDefinition, null, 2)); }}>Edit</button><button onClick={() => generateRule.mutate(r.ruleId)}>Generate</button><button onClick={() => deleteRule.mutate(r.ruleId)}>Delete</button></div></div>)}</div></section>
    </div>
  </div>;
}
const card = { border:'1px solid #243043', borderRadius:8, background:'#111827', padding:16 } as const;
const row = { display:'flex', justifyContent:'space-between', padding:'8px 0', borderBottom:'1px solid #243043' } as const;
const input = { width:'100%', padding:8, marginBottom:8, background:'#0f172a', color:'inherit', border:'1px solid #243043', borderRadius:8 } as const;
