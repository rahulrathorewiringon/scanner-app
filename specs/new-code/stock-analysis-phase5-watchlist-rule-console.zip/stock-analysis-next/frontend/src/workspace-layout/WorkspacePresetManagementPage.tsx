import { useState } from 'react';
import { useWorkspaceStore } from '../stores/workspace.store';
import { useDeleteWorkspaceLayoutPresetMutation, useMarkDefaultWorkspaceLayoutPresetMutation, useMarkFavoriteWorkspaceLayoutPresetMutation, useSaveWorkspaceLayoutPresetMutation, useUpdateWorkspaceLayoutPresetMutation, useWorkspaceLayoutPresetsQuery } from '../hooks/api/useWorkspaceLayoutPresets';

export default function WorkspacePresetManagementPage() {
  const userId = useWorkspaceStore((s) => s.userId);
  const exchangeCode = useWorkspaceStore((s) => s.exchangeCode);
  const workspaceModelJson = useWorkspaceStore((s) => s.workspaceModelJson);
  const presets = useWorkspaceLayoutPresetsQuery(userId);
  const savePreset = useSaveWorkspaceLayoutPresetMutation();
  const updatePreset = useUpdateWorkspaceLayoutPresetMutation();
  const deletePreset = useDeleteWorkspaceLayoutPresetMutation(userId);
  const markDefault = useMarkDefaultWorkspaceLayoutPresetMutation(userId);
  const markFavorite = useMarkFavoriteWorkspaceLayoutPresetMutation(userId);
  const [name, setName] = useState('My Layout');
  const [editingId, setEditingId] = useState<string | null>(null);

  const submit = () => {
    const layoutJson = workspaceModelJson ? JSON.parse(workspaceModelJson) : {};
    if (editingId) updatePreset.mutate({ presetId: editingId, userId, name, exchangeCode, layoutJson, isDefault: false, isFavorite: false });
    else savePreset.mutate({ userId, name, exchangeCode, layoutJson, isDefault: false, isFavorite: false });
    setEditingId(null); setName('My Layout');
  };

  return <div style={{ padding:20, display:'grid', gap:16 }}>
    <div><h1 style={{ margin:0 }}>Workspace Preset Management</h1><div style={{ opacity:0.75 }}>Default/favorite handling with backend persistence</div></div>
    <div style={{ display:'grid', gridTemplateColumns:'0.8fr 1.2fr', gap:16 }}>
      <section style={card}><input value={name} onChange={(e) => setName(e.target.value)} style={input} /><button onClick={submit}>{editingId ? 'Update Preset' : 'Save Preset'}</button></section>
      <section style={card}>{(presets.data ?? []).map((p) => <div key={p.presetId} style={{ border:'1px solid #243043', borderRadius:8, padding:8, marginBottom:8 }}><div><strong>{p.name}</strong> {p.isDefault ? '★' : ''} {p.isFavorite ? '♥' : ''}</div><div style={{ display:'flex', gap:8, flexWrap:'wrap', marginTop:8 }}><button onClick={() => { setEditingId(p.presetId); setName(p.name); }}>Edit</button><button onClick={() => markDefault.mutate(p.presetId)}>Default</button><button onClick={() => markFavorite.mutate({ presetId: p.presetId, favorite: !p.isFavorite })}>{p.isFavorite ? 'Unfavorite' : 'Favorite'}</button><button onClick={() => deletePreset.mutate(p.presetId)}>Delete</button></div></div>)}</section>
    </div>
  </div>;
}
const card = { border:'1px solid #243043', borderRadius:8, background:'#111827', padding:16 } as const;
const input = { width:'100%', padding:8, marginBottom:8, background:'#0f172a', color:'inherit', border:'1px solid #243043', borderRadius:8 } as const;
