import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiDelete, apiGet, apiPost, apiPut } from '../../lib/apiClient';
import type { SaveWorkspaceLayoutPresetRequestDto, UpdateWorkspaceLayoutPresetRequestDto, WorkspaceLayoutPreset } from '../../types/workspace.types';

export function useWorkspaceLayoutPresetsQuery(userId: string) {
  return useQuery({ queryKey: ['workspace-layout-presets', userId], queryFn: () => apiGet<WorkspaceLayoutPreset[]>('/api/workspace/layout-presets', { userId }), enabled: !!userId });
}
export function useSaveWorkspaceLayoutPresetMutation() {
  const qc = useQueryClient();
  return useMutation({ mutationFn: (body: SaveWorkspaceLayoutPresetRequestDto) => apiPost<WorkspaceLayoutPreset>('/api/workspace/layout-presets', body), onSuccess: (_d, vars) => qc.invalidateQueries({ queryKey: ['workspace-layout-presets', vars.userId] }) });
}
export function useUpdateWorkspaceLayoutPresetMutation() {
  const qc = useQueryClient();
  return useMutation({ mutationFn: (body: UpdateWorkspaceLayoutPresetRequestDto) => apiPut<WorkspaceLayoutPreset>(`/api/workspace/layout-presets/${body.presetId}`, body), onSuccess: (_d, vars) => qc.invalidateQueries({ queryKey: ['workspace-layout-presets', vars.userId] }) });
}
export function useMarkDefaultWorkspaceLayoutPresetMutation(userId: string) {
  const qc = useQueryClient();
  return useMutation({ mutationFn: (presetId: string) => apiPost<WorkspaceLayoutPreset>(`/api/workspace/layout-presets/${presetId}/default?userId=${encodeURIComponent(userId)}`, {}), onSuccess: () => qc.invalidateQueries({ queryKey: ['workspace-layout-presets', userId] }) });
}
export function useMarkFavoriteWorkspaceLayoutPresetMutation(userId: string) {
  const qc = useQueryClient();
  return useMutation({ mutationFn: ({ presetId, favorite }: { presetId: string; favorite: boolean }) => apiPost<WorkspaceLayoutPreset>(`/api/workspace/layout-presets/${presetId}/favorite?userId=${encodeURIComponent(userId)}&favorite=${favorite}`, {}), onSuccess: () => qc.invalidateQueries({ queryKey: ['workspace-layout-presets', userId] }) });
}
export function useDeleteWorkspaceLayoutPresetMutation(userId: string) {
  const qc = useQueryClient();
  return useMutation({ mutationFn: (presetId: string) => apiDelete<{ deleted: boolean }>('/api/workspace/layout-presets/' + presetId, { userId }), onSuccess: () => qc.invalidateQueries({ queryKey: ['workspace-layout-presets', userId] }) });
}
