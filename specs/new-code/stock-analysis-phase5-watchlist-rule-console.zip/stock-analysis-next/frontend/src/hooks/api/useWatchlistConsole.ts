import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiDelete, apiGet, apiPost, apiPut } from '../../lib/apiClient';
import type { AlertRuleDto, GenerateWatchlistFromRuleResponseDto, SaveWatchlistGenerationRuleRequestDto, UpdateWatchlistGenerationRuleRequestDto, WatchlistDefinitionDto, WatchlistGenerationRuleDto, WatchlistItemDto } from '../../types/watchlist.types';

export function useWatchlistsQuery(userId: string) {
  return useQuery({ queryKey: ['watchlists', userId], queryFn: () => apiGet<WatchlistDefinitionDto[]>('/api/watchlists', { userId }), enabled: !!userId });
}
export function useWatchlistItemsQuery(userId: string, watchlistId?: string | null) {
  return useQuery({ queryKey: ['watchlist-items', userId, watchlistId], queryFn: () => apiGet<WatchlistItemDto[]>(`/api/watchlists/${watchlistId}/items`, { userId }), enabled: !!userId && !!watchlistId });
}
export function useWatchlistRulesQuery(userId: string) {
  return useQuery({ queryKey: ['watchlist-rules', userId], queryFn: () => apiGet<WatchlistGenerationRuleDto[]>('/api/watchlists/rules', { userId }), enabled: !!userId });
}
export function useSaveWatchlistRuleMutation(userId: string) {
  const qc = useQueryClient();
  return useMutation({ mutationFn: (body: SaveWatchlistGenerationRuleRequestDto) => apiPost<WatchlistGenerationRuleDto>('/api/watchlists/rules', body), onSuccess: () => qc.invalidateQueries({ queryKey: ['watchlist-rules', userId] }) });
}
export function useUpdateWatchlistRuleMutation(userId: string) {
  const qc = useQueryClient();
  return useMutation({ mutationFn: (body: UpdateWatchlistGenerationRuleRequestDto) => apiPut<WatchlistGenerationRuleDto>(`/api/watchlists/rules/${body.ruleId}`, body), onSuccess: () => qc.invalidateQueries({ queryKey: ['watchlist-rules', userId] }) });
}
export function useDeleteWatchlistRuleMutation(userId: string) {
  const qc = useQueryClient();
  return useMutation({ mutationFn: (ruleId: string) => apiDelete<{deleted:boolean}>(`/api/watchlists/rules/${ruleId}`, { userId }), onSuccess: () => qc.invalidateQueries({ queryKey: ['watchlist-rules', userId] }) });
}
export function useGenerateWatchlistRuleMutation(userId: string) {
  const qc = useQueryClient();
  return useMutation({ mutationFn: (ruleId: string) => apiPost<GenerateWatchlistFromRuleResponseDto>(`/api/watchlists/rules/${ruleId}/generate?userId=${encodeURIComponent(userId)}`, {}), onSuccess: () => { qc.invalidateQueries({ queryKey: ['watchlist-rules', userId] }); qc.invalidateQueries({ queryKey: ['watchlists', userId] }); } });
}
export function useAlertRulesQuery(userId: string) {
  return useQuery({ queryKey: ['alert-rules', userId], queryFn: () => apiGet<AlertRuleDto[]>('/api/alerts/rules', { userId }), enabled: !!userId });
}
export function useUpdateAlertStatusMutation(userId: string) {
  const qc = useQueryClient();
  return useMutation({ mutationFn: ({ alertRuleId, status }: { alertRuleId: string; status: string }) => apiPut<{updated:boolean}>(`/api/alerts/rules/${alertRuleId}/status?userId=${encodeURIComponent(userId)}&status=${encodeURIComponent(status)}`, {}), onSuccess: () => qc.invalidateQueries({ queryKey: ['alert-rules', userId] }) });
}
