import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiDelete, apiGet, apiPost, apiPut } from '../../lib/apiClient';
import type { SavedScreenerShareDto, SavedScreenerTagDto, SaveScreenerShareRequestDto } from '../../types/screener.types';

export function useSavedScreenerTagsQuery(screenerId?: string | null, userId?: string | null) {
  return useQuery({ queryKey: ['saved-screener-tags', screenerId, userId], queryFn: () => apiGet<SavedScreenerTagDto[]>(`/api/screener/saved-definitions/${screenerId}/tags`, { userId: userId ?? '' }), enabled: !!screenerId && !!userId });
}
export function useReplaceSavedScreenerTagsMutation(screenerId: string, userId: string) {
  const qc = useQueryClient();
  return useMutation({ mutationFn: (tags: string[]) => apiPut<SavedScreenerTagDto[]>(`/api/screener/saved-definitions/${screenerId}/tags?userId=${encodeURIComponent(userId)}`, tags), onSuccess: () => qc.invalidateQueries({ queryKey: ['saved-screener-tags', screenerId, userId] }) });
}
export function useSavedScreenerSharesQuery(screenerId?: string | null, ownerUserId?: string | null) {
  return useQuery({ queryKey: ['saved-screener-shares', screenerId, ownerUserId], queryFn: () => apiGet<SavedScreenerShareDto[]>(`/api/screener/saved-definitions/${screenerId}/shares`, { ownerUserId: ownerUserId ?? '' }), enabled: !!screenerId && !!ownerUserId });
}
export function useSaveSavedScreenerShareMutation(screenerId: string, ownerUserId: string) {
  const qc = useQueryClient();
  return useMutation({ mutationFn: (body: Omit<SaveScreenerShareRequestDto, 'screenerId'|'ownerUserId'>) => apiPost<SavedScreenerShareDto>(`/api/screener/saved-definitions/${screenerId}/shares`, { screenerId, ownerUserId, ...body }), onSuccess: () => qc.invalidateQueries({ queryKey: ['saved-screener-shares', screenerId, ownerUserId] }) });
}
export function useDeleteSavedScreenerShareMutation(screenerId: string, ownerUserId: string) {
  const qc = useQueryClient();
  return useMutation({ mutationFn: (sharedWithUserId: string) => apiDelete<{deleted:boolean}>(`/api/screener/saved-definitions/${screenerId}/shares`, { ownerUserId, sharedWithUserId }), onSuccess: () => qc.invalidateQueries({ queryKey: ['saved-screener-shares', screenerId, ownerUserId] }) });
}
