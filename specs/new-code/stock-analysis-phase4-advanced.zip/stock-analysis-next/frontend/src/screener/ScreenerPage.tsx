import type { CSSProperties } from 'react';
import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { useWorkspaceStore } from '../stores/workspace.store';
import { useScreenerFilterMetadataQuery } from '../hooks/api/useScreenerFilterMetadataQuery';
import { useScreenerCountMutation } from '../hooks/api/useScreenerCountMutation';
import { useScreenerRunMutation } from '../hooks/api/useScreenerRunMutation';
import { useSavedScreenersQuery, useSaveScreenerMutation, useDeleteSavedScreenerMutation, useUpdateSavedScreenerMutation } from '../hooks/api/useSavedScreeners';
import { useScreenerBulkActionMutation } from '../hooks/api/useScreenerBulkActionMutation';
import type { SavedScreenerDefinition, ScreenerBulkActionRequestDto, ScreenerConditionNodeDto, ScreenerFieldDef, ScreenerFilterGroupDto, ScreenerFilterNodeDto, ScreenerRunRequestDto, ScreenerSortSpec } from '../types/screener.types';

function id() { return Math.random().toString(36).slice(2, 10); }
function createCondition(field?: ScreenerFieldDef): ScreenerConditionNodeDto {
  return { type:'condition', id:id(), enabled:true, fieldGroup:field?.group ?? 'instrument', field:field?.key ?? 'symbol', timeframe:'day', operator:field?.operators?.[0] ?? 'eq', value:field?.options?.length ? { kind:'single', value:field.options[0].value } : { kind:'single', value:'' } };
}
function createGroup(): ScreenerFilterGroupDto { return { type:'group', id:id(), operator:'AND', enabled:true, children:[] }; }
function addChild(group: ScreenerFilterGroupDto, groupId: string, child: ScreenerFilterNodeDto): ScreenerFilterGroupDto { if (group.id === groupId) return { ...group, children:[...group.children, child] }; return { ...group, children: group.children.map((n) => n.type === 'group' ? addChild(n, groupId, child) : n) }; }
function removeNode(group: ScreenerFilterGroupDto, nodeId: string): ScreenerFilterGroupDto { return { ...group, children: group.children.filter((c) => c.id !== nodeId).map((c) => c.type === 'group' ? removeNode(c, nodeId) : c) }; }
function updateNode(group: ScreenerFilterGroupDto, targetId: string, updater: (node: ScreenerFilterNodeDto) => ScreenerFilterNodeDto): ScreenerFilterGroupDto { if (group.id === targetId) return updater(group) as ScreenerFilterGroupDto; return { ...group, children: group.children.map((child) => child.id === targetId ? updater(child) : child.type === 'group' ? updateNode(child, targetId, updater) : child) }; }
function replaceConditionByField(condition: ScreenerConditionNodeDto, field?: ScreenerFieldDef): ScreenerConditionNodeDto { return { ...condition, fieldGroup: field?.group ?? condition.fieldGroup, field: field?.key ?? condition.field, operator: field?.operators?.[0] ?? 'eq', value: field?.options?.length ? { kind:'single', value:field.options[0].value } : { kind:'single', value:'' } }; }

export default function ScreenerPage() {
  const exchangeCode = useWorkspaceStore((s) => s.exchangeCode);
  const tradeDate = useWorkspaceStore((s) => s.tradeDate);
  const userId = useWorkspaceStore((s) => s.userId);
  const setActiveInstrumentId = useWorkspaceStore((s) => s.setActiveInstrumentId);

  const [timeframe, setTimeframe] = useState<'hour'|'day'|'week'>('day');
  const [pageIndex, setPageIndex] = useState(0);
  const [pageSize, setPageSize] = useState(25);
  const [sort, setSort] = useState<ScreenerSortSpec[]>([{ field:'symbol', direction:'asc' }]);
  const [savedScreenerName, setSavedScreenerName] = useState('');
  const [editingScreenerId, setEditingScreenerId] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [bulkTargetName, setBulkTargetName] = useState('Default Watchlist');

  const metadata = useScreenerFilterMetadataQuery(exchangeCode);
  const countMutation = useScreenerCountMutation();
  const runMutation = useScreenerRunMutation();
  const savedScreenersQuery = useSavedScreenersQuery(userId);
  const saveScreenerMutation = useSaveScreenerMutation();
  const updateScreenerMutation = useUpdateSavedScreenerMutation();
  const deleteSavedMutation = useDeleteSavedScreenerMutation(userId);
  const bulkActionMutation = useScreenerBulkActionMutation();

  const [filterTree, setFilterTree] = useState<ScreenerFilterGroupDto>({ type:'group', id:'root', operator:'AND', enabled:true, children:[] });

  const request = useMemo<ScreenerRunRequestDto>(() => ({ exchangeCode, tradeDate, defaultTimeframe: timeframe, filterTree, pagination:{ pageIndex, pageSize }, sort }), [exchangeCode, tradeDate, timeframe, filterTree, pageIndex, pageSize, sort]);
  const totalPages = runMutation.data ? Math.max(1, Math.ceil(runMutation.data.totalRows / runMutation.data.pageSize)) : 1;
  const results = runMutation.data?.rows ?? [];

  const runCount = () => countMutation.mutate(request);
  const runScreener = () => runMutation.mutate(request);
  const saveCurrentScreener = () => {
    const name = savedScreenerName.trim(); if (!name) return;
    if (editingScreenerId) {
      updateScreenerMutation.mutate({ screenerId: editingScreenerId, userId, name, exchangeCode, tradeDate, defaultTimeframe: timeframe, filterTree, sortSpec: sort, pageSize });
    } else {
      saveScreenerMutation.mutate({ userId, name, exchangeCode, tradeDate, defaultTimeframe: timeframe, filterTree, sortSpec: sort, pageSize });
    }
    setSavedScreenerName('');
    setEditingScreenerId(null);
  };
  const loadSavedScreener = (item: SavedScreenerDefinition) => { setTimeframe(item.defaultTimeframe); setFilterTree(item.filterTree); setSort(item.sortSpec); setPageSize(item.pageSize); setPageIndex(0); setSavedScreenerName(item.name); setEditingScreenerId(item.screenerId); };
  const executePage = (nextPage: number) => { setPageIndex(nextPage); runMutation.mutate({ ...request, pagination:{ ...request.pagination, pageIndex: nextPage } }); };
  const changeSort = (field: ScreenerSortSpec['field']) => { const nextSort = sort[0]?.field === field ? [{ field, direction: sort[0].direction === 'asc' ? 'desc' : 'asc' }] : [{ field, direction:'asc' }]; setSort(nextSort); runMutation.mutate({ ...request, sort: nextSort }); };
  const toggleSelected = (instrumentId: number, checked: boolean) => { setSelectedIds((prev) => checked ? Array.from(new Set([...prev, instrumentId])) : prev.filter((id) => id !== instrumentId)); };
  const toggleAll = (checked: boolean) => setSelectedIds(checked ? Array.from(new Set(results.map((r) => r.instrumentId))) : []);
  const applyBulkAction = (actionType: ScreenerBulkActionRequestDto['actionType']) => { if (!selectedIds.length) return; const payload = actionType === 'ADD_TO_WATCHLIST' ? { exchangeCode, tradeDate, watchlistName: bulkTargetName } : actionType === 'CREATE_ALERT' ? { exchangeCode, ruleName: bulkTargetName || 'Bulk Alert Rule', ruleType: 'PRICE_ACTION' } : { exchangeCode, tradeDate }; bulkActionMutation.mutate({ userId, actionType, instrumentIds: selectedIds, payload }); };

  return <div style={{ padding:20, display:'grid', gap:16 }}>
    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
      <div><h1 style={{ margin:0 }}>Screener</h1><div style={{ opacity:0.75 }}>Backend-persisted screeners, edit/update, bulk actions, pagination, and sort</div></div>
      <div style={{ display:'flex', gap:10 }}><button onClick={runCount} style={{ padding:'10px 14px', background:'#334155', borderRadius:8 }}>Count</button><button onClick={runScreener} style={{ padding:'10px 14px', background:'#2563eb', borderRadius:8 }}>Run Screener</button></div>
    </div>

    <div style={{ display:'grid', gridTemplateColumns:'1.2fr 0.8fr', gap:16 }}>
      <div style={{ border:'1px solid #243043', borderRadius:8, background:'#111827', padding:16, display:'grid', gap:12 }}>
        <div style={{ display:'flex', gap:12, alignItems:'center', flexWrap:'wrap' }}>
          <select value={timeframe} onChange={(e) => { setTimeframe(e.target.value as any); setPageIndex(0); }} style={{ padding:8 }}><option value='hour'>hour</option><option value='day'>day</option><option value='week'>week</option></select>
          <button onClick={() => setFilterTree(addChild(filterTree, 'root', createCondition(metadata.data?.fields?.[0])))}>+ Condition</button>
          <button onClick={() => setFilterTree(addChild(filterTree, 'root', createGroup()))}>+ Group</button>
          <input value={savedScreenerName} onChange={(e) => setSavedScreenerName(e.target.value)} placeholder='Save screener as...' style={{ padding:8, minWidth:220 }} />
          <button onClick={saveCurrentScreener}>{editingScreenerId ? 'Update Definition' : 'Save Definition'}</button>
          {editingScreenerId && <button onClick={() => { setEditingScreenerId(null); setSavedScreenerName(''); }}>Cancel Edit</button>}
        </div>
        <FilterGroupEditor group={filterTree} metadata={metadata.data?.fields ?? []} onChange={setFilterTree} onAddCondition={(groupId) => setFilterTree((prev) => addChild(prev, groupId, createCondition(metadata.data?.fields?.[0])))} onAddGroup={(groupId) => setFilterTree((prev) => addChild(prev, groupId, createGroup()))} onRemoveNode={(nodeId) => setFilterTree((prev) => removeNode(prev, nodeId))} />
      </div>

      <div style={{ border:'1px solid #243043', borderRadius:8, background:'#111827', padding:16, display:'grid', gap:12 }}>
        <h3 style={{ marginTop:0 }}>Execution Summary</h3>
        <div>Count: {countMutation.data?.count ?? '—'}</div><div>Rows: {runMutation.data?.totalRows ?? '—'}</div><div>Selected: {selectedIds.length}</div>
        <input value={bulkTargetName} onChange={(e) => setBulkTargetName(e.target.value)} placeholder='Watchlist / Alert name' style={{ padding:8 }} />
        <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
          <button onClick={() => applyBulkAction('ADD_TO_WATCHLIST')}>Add to Watchlist</button>
          <button onClick={() => applyBulkAction('CREATE_ALERT')}>Create Alert</button>
          <button onClick={() => applyBulkAction('EXPORT_SELECTION')}>Export Selection</button>
        </div>
        {bulkActionMutation.data && <div style={{ color:'#86efac' }}>{bulkActionMutation.data.message} {bulkActionMutation.data.domainEntityType ? `(${bulkActionMutation.data.domainEntityType}: ${bulkActionMutation.data.domainEntityId})` : ''}</div>}
        <div style={{ borderTop:'1px solid #243043', paddingTop:10 }}>
          <h4 style={{ margin:'0 0 8px 0' }}>Saved Screeners</h4>
          <div style={{ display:'grid', gap:8, maxHeight:220, overflow:'auto' }}>
            {(savedScreenersQuery.data ?? []).length === 0 ? <div style={{ opacity:0.75 }}>No saved definitions yet.</div> : (savedScreenersQuery.data ?? []).map((item) => (
              <div key={item.screenerId} style={{ border:'1px solid #243043', borderRadius:8, padding:8, display:'grid', gap:6 }}>
                <div style={{ display:'flex', justifyContent:'space-between', gap:8 }}><strong>{item.name}</strong><button onClick={() => deleteSavedMutation.mutate(item.screenerId)}>Delete</button></div>
                <div style={{ fontSize:12, opacity:0.75 }}>{item.defaultTimeframe} · {item.sortSpec?.[0]?.field} {item.sortSpec?.[0]?.direction}</div>
                <div style={{ display:'flex', gap:8 }}><button onClick={() => loadSavedScreener(item)}>Load / Edit</button></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>

    <div style={{ border:'1px solid #243043', borderRadius:8, background:'#111827', padding:16 }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12, gap:12, flexWrap:'wrap' }}>
        <h3 style={{ marginTop:0, marginBottom:0 }}>Results</h3>
        <div style={{ display:'flex', gap:8, alignItems:'center', flexWrap:'wrap' }}>
          <label><input type='checkbox' checked={selectedIds.length > 0 && selectedIds.length === results.length && results.length > 0} onChange={(e) => toggleAll(e.target.checked)} /> Select page</label>
          <label>Page Size <select value={pageSize} onChange={(e) => { const next = Number(e.target.value); setPageSize(next); setPageIndex(0); }}><option value={10}>10</option><option value={25}>25</option><option value={50}>50</option></select></label>
          <button onClick={() => executePage(Math.max(0, pageIndex - 1))} disabled={pageIndex === 0}>Prev</button>
          <div>Page {pageIndex + 1} / {totalPages}</div>
          <button onClick={() => executePage(Math.min(totalPages - 1, pageIndex + 1))} disabled={pageIndex >= totalPages - 1}>Next</button>
        </div>
      </div>
      {runMutation.isPending ? <div>Running screener…</div> : runMutation.error ? <div>Failed to run screener.</div> : (
        <table style={{ width:'100%', borderCollapse:'collapse' }}>
          <thead><tr><th style={th}></th><SortableHeader label='Symbol' onClick={() => changeSort('symbol')} active={sort[0]?.field==='symbol'} direction={sort[0]?.direction} /><th style={th}>Sector</th><th style={th}>TF</th><SortableHeader label='Close' onClick={() => changeSort('latestClose')} active={sort[0]?.field==='latestClose'} direction={sort[0]?.direction} /><SortableHeader label='Candle' onClick={() => changeSort('currentCandleType')} active={sort[0]?.field==='currentCandleType'} direction={sort[0]?.direction} /><SortableHeader label='Pivot' onClick={() => changeSort('latestPivotType')} active={sort[0]?.field==='latestPivotType'} direction={sort[0]?.direction} /><th style={th}>Prev Pivot</th><th style={th}>SMA</th><th style={th}>Signal</th><SortableHeader label='Updated' onClick={() => changeSort('updatedAt')} active={sort[0]?.field==='updatedAt'} direction={sort[0]?.direction} /><th style={th}>Actions</th></tr></thead>
          <tbody>
            {results.map((row) => (
              <tr key={`${row.instrumentId}-${row.timeframe}`}>
                <td style={cell}><input type='checkbox' checked={selectedIds.includes(row.instrumentId)} onChange={(e) => toggleSelected(row.instrumentId, e.target.checked)} /></td>
                <td style={cell}>{row.symbol}</td><td style={cell}>{row.sector ?? '—'}</td><td style={cell}>{row.timeframe}</td><td style={cell}>{row.latestClose ?? '—'}</td><td style={cell}>{row.currentCandleType ?? '—'}</td><td style={cell}>{row.latestPivotType ?? '—'}</td><td style={cell}>{row.previousPivotType ?? '—'}</td><td style={cell}>{row.smaAlignmentSummary ?? '—'}</td><td style={cell}>{row.signalSummary ?? '—'}</td><td style={cell}>{row.updatedAt ?? '—'}</td>
                <td style={cell}><Link to='/workspace' onClick={() => setActiveInstrumentId(row.instrumentId)} style={{ color:'#60a5fa' }}>Open</Link></td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  </div>;
}

function SortableHeader({ label, onClick, active, direction }: { label: string; onClick: () => void; active: boolean; direction?: 'asc'|'desc' }) {
  return <th style={th}><button onClick={onClick} style={{ background:'transparent', border:'none', color:'inherit', cursor:'pointer', padding:0 }}>{label}{active ? (direction === 'asc' ? ' ↑' : ' ↓') : ''}</button></th>;
}

function FilterGroupEditor({ group, metadata, onChange, onAddCondition, onAddGroup, onRemoveNode }: { group: ScreenerFilterGroupDto; metadata: ScreenerFieldDef[]; onChange: (next: ScreenerFilterGroupDto) => void; onAddCondition: (groupId: string) => void; onAddGroup: (groupId: string) => void; onRemoveNode: (nodeId: string) => void; }) {
  return <div style={{ border:'1px solid #243043', borderRadius:8, padding:12, display:'grid', gap:10 }}>
    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
      <div style={{ display:'flex', gap:10, alignItems:'center' }}><strong>Group</strong><select value={group.operator} onChange={(e) => onChange(updateNode(group, group.id, (node) => ({ ...(node as ScreenerFilterGroupDto), operator: e.target.value as 'AND'|'OR' } as ScreenerFilterGroupDto)))}><option value='AND'>AND</option><option value='OR'>OR</option></select></div>
      {group.id !== 'root' && <button onClick={() => onRemoveNode(group.id)}>Remove Group</button>}
    </div>
    {group.children.map((node) => node.type === 'group' ? <FilterGroupEditor key={node.id} group={node} metadata={metadata} onChange={(next) => onChange(updateNode(group, node.id, () => next))} onAddCondition={onAddCondition} onAddGroup={onAddGroup} onRemoveNode={onRemoveNode} /> : <ConditionRow key={node.id} node={node} metadata={metadata} onChange={(next) => onChange(updateNode(group, node.id, () => next))} onRemove={() => onRemoveNode(node.id)} />)}
    <div style={{ display:'flex', gap:10 }}><button onClick={() => onAddCondition(group.id)}>+ Condition</button><button onClick={() => onAddGroup(group.id)}>+ Nested Group</button></div>
  </div>;
}

function ConditionRow({ node, metadata, onChange, onRemove }: { node: ScreenerConditionNodeDto; metadata: ScreenerFieldDef[]; onChange: (next: ScreenerConditionNodeDto) => void; onRemove: () => void; }) {
  const fieldDef = metadata.find((f) => f.key === node.field) ?? metadata[0];
  const options = metadata.filter((f) => f.group === node.fieldGroup);
  return <div style={{ border:'1px solid #243043', borderRadius:8, padding:10, display:'grid', gap:8 }}><div style={{ display:'grid', gridTemplateColumns:'repeat(5, minmax(0,1fr)) auto', gap:8 }}>
    <select value={node.fieldGroup} onChange={(e) => { const nextGroup = e.target.value as ScreenerConditionNodeDto['fieldGroup']; const nextField = metadata.find((f) => f.group === nextGroup); onChange(replaceConditionByField({ ...node, fieldGroup: nextGroup }, nextField)); }}><option value='instrument'>instrument</option><option value='sma'>sma</option><option value='pivot'>pivot</option><option value='candle'>candle</option><option value='signal'>signal</option></select>
    <select value={node.field} onChange={(e) => onChange(replaceConditionByField({ ...node, field: e.target.value }, metadata.find((f) => f.key === e.target.value)))}>{options.map((f) => <option key={f.key} value={f.key}>{f.label}</option>)}</select>
    <select value={node.timeframe} onChange={(e) => onChange({ ...node, timeframe: e.target.value as any })}><option value='current'>current</option><option value='hour'>hour</option><option value='day'>day</option><option value='week'>week</option></select>
    <select value={node.operator} onChange={(e) => onChange({ ...node, operator: e.target.value })}>{(fieldDef?.operators ?? ['eq']).map((op) => <option key={op} value={op}>{op}</option>)}</select>
    <ValueEditor node={node} fieldDef={fieldDef} onChange={onChange} />
    <button onClick={onRemove}>Remove</button>
  </div></div>;
}

function ValueEditor({ node, fieldDef, onChange }: { node: ScreenerConditionNodeDto; fieldDef?: ScreenerFieldDef; onChange: (next: ScreenerConditionNodeDto) => void; }) {
  if (node.operator === 'in') {
    if (fieldDef?.options?.length) {
      const selectedValues = Array.isArray((node.value as any).values) ? (node.value as any).values.map(String) : [];
      return <select multiple value={selectedValues} onChange={(e) => { const values = Array.from(e.target.selectedOptions).map((opt) => opt.value); onChange({ ...node, value: { kind: 'list', values } }); }}>{fieldDef.options.map((opt) => <option key={opt.value} value={opt.value}>{opt.label}</option>)}</select>;
    }
    return <input value={Array.isArray((node.value as any).values) ? (node.value as any).values.join(',') : ''} placeholder='a,b,c' onChange={(e) => onChange({ ...node, value: { kind: 'list', values: e.target.value.split(',').map((v) => v.trim()).filter(Boolean) } })} />;
  }
  if (fieldDef?.options?.length) return <select value={String((node.value as any).value ?? '')} onChange={(e) => onChange({ ...node, value: { kind: 'single', value: e.target.value } })}>{fieldDef.options.map((opt) => <option key={opt.value} value={opt.value}>{opt.label}</option>)}</select>;
  return <input value={String((node.value as any).value ?? '')} onChange={(e) => { const raw = e.target.value; const nextValue = raw !== '' && !Number.isNaN(Number(raw)) ? Number(raw) : raw; onChange({ ...node, value: { kind: 'single', value: nextValue } }); }} />;
}

const th: CSSProperties = { textAlign:'left', padding:'8px 6px', borderBottom:'1px solid #243043' };
const cell: CSSProperties = { padding:'8px 6px', borderBottom:'1px solid #1f2937' };
